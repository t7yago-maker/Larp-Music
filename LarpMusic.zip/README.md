# LARP MUSIC

App Android nativo de streaming de música (Kotlin + Jetpack Compose), com identidade visual
glassmorphism, player real (Media3/ExoPlayer), equalizador real, conta local com autenticação
real, playlists e integração com o catálogo aberto da **Jamendo**.

Este repositório foi montado para compilar o APK **via GitHub Actions** (`.github/workflows/build.yml`),
porque o ambiente onde este projeto foi gerado não tem o Android SDK instalado — só o GitHub
Actions runner (ou sua própria máquina com Android Studio) consegue de fato baixar as
dependências do Google/Maven e gerar o `.apk`. Veja "Como compilar" abaixo.

## Como compilar o APK

### Opção 1 — GitHub Actions (o que você pediu)
1. Crie um repositório no GitHub e suba todo este conteúdo (`git init`, `git add -A`,
   `git commit`, `git push`).
2. **(Totalmente opcional)** O catálogo principal agora é o **Audius** e funciona sem nenhuma chave nem cadastro. Se quiser *somar* o catálogo da Jamendo, registre um client id gratuito na Jamendo em
   https://devportal.jamendo.com/ e adicione como *Repository secret*:
   `Settings → Secrets and variables → Actions → New repository secret`
   - Nome: `JAMENDO_CLIENT_ID`
   - Valor: seu client id
   Sem isso, tudo continua funcionando só com o Audius.
3. Abra a aba **Actions** do repositório e rode o workflow **Build LARP MUSIC APK**
   (ou apenas dê um push na branch `main` — ele roda sozinho).
4. Ao final, baixe o artefato `larpmusic-debug-apk` gerado pelo job — é o `.apk` instalável.

### Opção 2 — Assinar um APK de release (opcional)
Para gerar também um APK assinado de release, crie um keystore e adicione estes secrets:
`RELEASE_KEYSTORE_BASE64` (o arquivo `.jks`/`.keystore` codificado em base64),
`RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`. O workflow detecta
os secrets automaticamente e sobe também o artefato `larpmusic-release-apk`.

### Opção 3 — Build local (Android Studio)
1. Abra a pasta do projeto no Android Studio (Koala+ recomendado).
2. Copie `local.properties.example` para `local.properties` e preencha `sdk.dir` e,
   opcionalmente, `JAMENDO_CLIENT_ID`.
3. Rode `./gradlew assembleDebug` (o Android Studio baixa o `gradle-wrapper.jar` sozinho na
   primeira sincronização) ou simplesmente clique em Run.

## O que está implementado de verdade (sem dados falsos)

- **Visual glassmorphism neutro** em todas as telas, nav bar, mini player, modais e configurações
  (`ui/theme`, `ui/components/GlassComponents.kt`). Blur real do fundo funciona em Android 12+
  (API 31+, via `Modifier.blur` do Compose); em versões anteriores o painel permanece translúcido
  com borda, só sem o desfoque — limitação documentada da plataforma, não um recurso faltando.
- **Catálogo e busca via Audius (sem chave) + Jamendo opcional** (músicas, artistas, álbuns, lançamentos, populares) —
  `data/remote/jamendo`, `data/repository/MusicRepository.kt`. Sem scraping, sem DRM, sem
  credenciais de terceiros. Se `JAMENDO_CLIENT_ID` não estiver configurado, a UI mostra
  explicitamente "catálogo não configurado" em vez de fingir que há resultados.
- **Player real** com Media3/ExoPlayer rodando em `MediaSessionService` (`player/PlaybackService.kt`):
  play/pause, próxima/anterior, barra de progresso, shuffle, repeat (off/one/all), fila,
  notificação de mídia, controles na tela de bloqueio, retomada automática, integração com
  botões de fone Bluetooth — tudo via Media3, não simulado.
- **Equalizador real** (`player/EqualizerManager.kt`) usando `android.media.audiofx.Equalizer`
  anexado à sessão de áudio do ExoPlayer — os presets realmente alteram o sinal de áudio.
  Os sliders customizados movem as bandas reais do equalizador do aparelho.
- **Conta local real** (`data/repository/AuthRepository.kt`): cadastro, login, logout, edição de
  perfil, exclusão de conta — com senha hasheada (bcrypt/jBCrypt) e sessão persistida via Room +
  DataStore. Não há Firebase/backend de nuvem configurado (ver "O que falta configurar").
- **Playlists completas** (`data/repository/PlaylistRepository.kt`): criar, renomear, excluir,
  duplicar, pública/privada, adicionar/remover/reordenar faixas, tela própria por playlist.
- **Biblioteca** com favoritos, playlists, artistas seguidos e histórico, todos persistidos em
  Room de verdade (sem dados estáticos).
- **Configurações de áudio** persistidas via DataStore: normalização de volume, crossfade (valor),
  reprodução contínua, economia de dados, temporizador de desligamento (valor).

## O que falta configurar / limitações conhecidas (declaradas, não escondidas)

- **Cloud sync / Firebase**: a especificação pede autenticação "real" e sync na nuvem. Sem um
  projeto Firebase (ou outro backend) configurado por você, a conta é 100% local neste device —
  documentado aqui, não fingido como sincronizado.
- **Crossfade e economia de dados**: o valor é salvo em `SettingsDataStore`, mas ainda não está
  conectado ao pipeline de reprodução do ExoPlayer (crossfade real exige lógica customizada de
  transição entre `MediaItem`s; economia de dados exige trocar o `audioformat` nas chamadas à
  Jamendo). A UI não finge que esses controles já afetam o áudio.
- **Temporizador de desligamento**: o valor é salvo, mas ainda não dispara a pausa automática da
  reprodução — falta o agendador em `PlayerViewModel`/`PlaybackService`.
- **Histórico de busca**: fica apenas na memória da sessão atual (não persistido em disco ainda).
- **Letras sincronizadas**: a API da Jamendo não fornece letras; a tela de player não exibe letras
  porque não há fonte licenciada integrada — melhor não mostrar nada do que inventar.
- **Áudio offline / downloads**: não implementado nesta versão.
- **Audius / SoundCloud**: a arquitetura já é modular por `MusicSource` para receber novas fontes
  sem reescrever o app, mas só a Jamendo está de fato conectada agora.
- **Ícone do app**: é um placeholder vetorial simples (fundo neutro + ícone minimalista),
  não uma arte final de marca.

## Arquitetura

```
app/src/main/java/com/larpmusic/app/
├── data/
│   ├── remote/jamendo/     # Retrofit API, DTOs, mapper → domain
│   ├── local/db/           # Room: entidades, DAOs, AppDatabase
│   ├── local/datastore/    # DataStore de configurações/sessão
│   └── repository/         # Music, Auth, Playlist — única fonte de verdade para a UI
├── domain/model/           # Modelos de domínio (Track, Artist, Album, Playlist, User...)
├── player/                 # PlaybackService (Media3), PlayerController, EqualizerManager
├── di/                     # Módulos Hilt
└── ui/
    ├── theme/               # Design system glass (cores neutras, tipografia)
    ├── components/          # GlassSurface/Card, bottom nav, mini player, track rows
    ├── navigation/          # NavHost + rotas
    └── auth/home/explore/search/library/profile/player/playlist/settings/
```

Build types: `debug` (sem minify, applicationId com sufixo `.debug`) e `release`
(minify + shrink de recursos, assinatura via secrets do CI quando presentes).


## Catálogo (Deezer + YouTube)

- **Deezer** (sem chave): charts/hits, capas e metadados. Cada faixa toca a versão **completa** procurada no YouTube Music
  (casada por artista + título + duração); se não achar, toca a prévia de 30s do Deezer.
- **YouTube Music** (via NewPipeExtractor): busca direta de músicas (funk automotivo, remixes, etc.), tocadas por inteiro.
- Jamendo continua opcional (`JAMENDO_CLIENT_ID`).

**Avisos:** extrair áudio do YouTube viola os termos de uso do YouTube e pode quebrar quando o YouTube muda algo
(atualize a versão do `NewPipeExtractor` em `app/build.gradle.kts`). O NewPipeExtractor é **GPL-3.0**: se você distribuir
o APK, o código do app precisa ser publicado sob GPL-3.0 também.
