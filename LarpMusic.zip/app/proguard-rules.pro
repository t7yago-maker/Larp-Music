# Keep Retrofit/Gson model classes
-keep class com.larpmusic.app.data.remote.jamendo.** { *; }
-keep class com.larpmusic.app.data.remote.audius.** { *; }
-keep class com.larpmusic.app.data.local.db.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn retrofit2.**

# NewPipeExtractor (YouTube)
-keep class org.schabi.newpipe.extractor.** { *; }
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
-dontwarn javax.script.**
-dontwarn java.beans.**
-keep class com.larpmusic.app.data.remote.deezer.** { *; }
