package com.larpmusic.app.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.larpmusic.app.R

/** Sons curtinhos e relaxantes (estilo bolha/pop ASMR) tocados em todo toque do app. */
object SoundFx {
    private var pool: SoundPool? = null
    private var ids = intArrayOf()
    @Volatile var enabled = true

    fun init(context: Context) {
        enabled = context.getSharedPreferences("larp_ui", Context.MODE_PRIVATE).getBoolean("sfx", true)
        if (pool != null) return
        val p = SoundPool.Builder().setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ).build()
        ids = intArrayOf(
            p.load(context, R.raw.pop1, 1),
            p.load(context, R.raw.pop2, 1),
            p.load(context, R.raw.pop3, 1)
        )
        pool = p
    }

    fun play() {
        if (!enabled) return
        val rate = 0.92f + kotlin.random.Random.nextFloat() * 0.16f // leve variação = mais gostoso
        pool?.play(ids.random(), 0.6f, 0.6f, 1, 0, rate)
    }

    fun setEnabled(context: Context, on: Boolean) {
        enabled = on
        context.getSharedPreferences("larp_ui", Context.MODE_PRIVATE).edit().putBoolean("sfx", on).apply()
    }

    fun release() { pool?.release(); pool = null }
}
