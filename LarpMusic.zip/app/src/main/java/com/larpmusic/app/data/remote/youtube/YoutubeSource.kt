package com.larpmusic.app.data.remote.youtube

import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

/** YouTube Music songs: search + full-length audio stream resolution via NewPipeExtractor. */
@Singleton
class YoutubeSource @Inject constructor(client: OkHttpClient) {

    private val youtube by lazy {
        NewPipe.init(NewPipeDownloader(client), Localization("pt", "BR"), ContentCountry("BR"))
        ServiceList.YouTube
    }

    private data class Cached(val url: String, val expiresAt: Long)
    private val urlCache = ConcurrentHashMap<String, Cached>()

    /** Search YouTube Music "Songs". Blocking-free: runs on IO. */
    suspend fun searchSongs(query: String): List<Track> = withContext(Dispatchers.IO) {
        searchItems(query).mapNotNull { it.toTrack() }
    }

    private fun searchItems(query: String): List<StreamInfoItem> {
        val handler = youtube.searchQHFactory.fromQuery(
            query, listOf(YoutubeSearchQueryHandlerFactory.MUSIC_SONGS), ""
        )
        return SearchInfo.getInfo(youtube, handler).relatedItems.filterIsInstance<StreamInfoItem>()
    }

    private fun StreamInfoItem.toTrack(): Track? {
        val vid = videoId(url) ?: return null
        val seconds = duration.toInt().coerceAtLeast(0)
        return Track(
            id = vid,
            source = MusicSource.YOUTUBE,
            title = name ?: return null,
            artistName = uploaderName?.removeSuffix(" - Topic") ?: "Artista desconhecido",
            artistId = "",
            albumName = null,
            albumId = null,
            artworkUrl = thumbnails.lastOrNull()?.url,
            streamUrl = StreamUris.youtube(vid),
            durationSeconds = seconds
        )
    }

    /** Resolved audio URL (+ the User-Agent it must be fetched with). Blocking; call off the main thread. */
    fun resolveVideo(videoId: String): String? {
        val now = System.currentTimeMillis()
        urlCache[videoId]?.takeIf { it.expiresAt > now }?.let { return it.url }
        val info = StreamInfo.getInfo(youtube, "https://www.youtube.com/watch?v=$videoId")
        val audio = info.audioStreams
            .filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .sortedWith(compareByDescending<AudioStream> { it.format?.name == "M4A" }.thenByDescending { it.averageBitrate })
            .firstOrNull() ?: return null
        val url = audio.content
        urlCache[videoId] = Cached(url, now + 4 * 60 * 60 * 1000L)
        return url
    }

    /** Finds the full version of a Deezer track on YouTube Music. Null if nothing plausible is found. */
    fun resolveMatch(artist: String, title: String, durationSeconds: Int): String? {
        val key = "m:$artist|$title"
        val now = System.currentTimeMillis()
        urlCache[key]?.takeIf { it.expiresAt > now }?.let { return it.url }
        val candidates = searchItems("$artist $title")
        val best = candidates.firstOrNull { durationSeconds <= 0 || abs(it.duration - durationSeconds) <= 20 }
            ?: return null
        val vid = videoId(best.url) ?: return null
        val url = resolveVideo(vid) ?: return null
        urlCache[key] = Cached(url, now + 4 * 60 * 60 * 1000L)
        return url
    }

    private fun videoId(url: String?): String? =
        url?.let { Regex("[?&]v=([\\w-]{11})").find(it)?.groupValues?.get(1) }
}
