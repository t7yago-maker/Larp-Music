package com.larpmusic.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class LarpMusicApp : Application()
