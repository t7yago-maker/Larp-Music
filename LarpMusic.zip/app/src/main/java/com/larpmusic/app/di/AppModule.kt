package com.larpmusic.app.di

import android.content.Context
import androidx.room.Room
import com.google.gson.Gson
import com.larpmusic.app.data.local.datastore.SettingsDataStore
import com.larpmusic.app.data.local.db.AppDatabase
import com.larpmusic.app.data.local.db.FavoriteDao
import com.larpmusic.app.data.local.db.FollowedArtistDao
import com.larpmusic.app.data.local.db.HistoryDao
import com.larpmusic.app.data.local.db.PlaylistDao
import com.larpmusic.app.data.local.db.SessionDao
import com.larpmusic.app.data.local.db.TrackCacheDao
import com.larpmusic.app.data.local.db.UserDao
import com.larpmusic.app.data.remote.audius.AudiusApi
import com.larpmusic.app.data.remote.deezer.DeezerApi
import com.larpmusic.app.data.remote.jamendo.JamendoApi
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

private const val JAMENDO_BASE_URL = "https://api.jamendo.com/v3.0/"

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "larpmusic.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideUserDao(db: AppDatabase): UserDao = db.userDao()
    @Provides fun provideSessionDao(db: AppDatabase): SessionDao = db.sessionDao()
    @Provides fun provideTrackCacheDao(db: AppDatabase): TrackCacheDao = db.trackCacheDao()
    @Provides fun provideFavoriteDao(db: AppDatabase): FavoriteDao = db.favoriteDao()
    @Provides fun provideFollowedArtistDao(db: AppDatabase): FollowedArtistDao = db.followedArtistDao()
    @Provides fun provideHistoryDao(db: AppDatabase): HistoryDao = db.historyDao()
    @Provides fun providePlaylistDao(db: AppDatabase): PlaylistDao = db.playlistDao()

    @Provides
    @Singleton
    fun provideSettingsDataStore(@ApplicationContext context: Context): SettingsDataStore =
        SettingsDataStore(context)

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    @Named("jamendo")
    fun provideJamendoRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(JAMENDO_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(Gson()))
            .build()

    @Provides
    @Singleton
    @Named("audius")
    fun provideAudiusRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(AudiusApi.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(Gson()))
            .build()

    @Provides
    @Singleton
    fun provideJamendoApi(@Named("jamendo") retrofit: Retrofit): JamendoApi =
        retrofit.create(JamendoApi::class.java)

    @Provides
    @Singleton
    fun provideAudiusApi(@Named("audius") retrofit: Retrofit): AudiusApi =
        retrofit.create(AudiusApi::class.java)

    @Provides
    @Singleton
    @Named("deezer")
    fun provideDeezerRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(DeezerApi.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(Gson()))
            .build()

    @Provides
    @Singleton
    fun provideDeezerApi(@Named("deezer") retrofit: Retrofit): DeezerApi =
        retrofit.create(DeezerApi::class.java)
}
