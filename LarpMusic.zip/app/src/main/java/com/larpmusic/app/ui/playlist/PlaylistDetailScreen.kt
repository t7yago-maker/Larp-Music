package com.larpmusic.app.ui.playlist

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.larpmusic.app.ui.components.TrackRow
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpBackground
import com.larpmusic.app.ui.components.liquidBackground
import com.larpmusic.app.ui.theme.LarpTextPrimary

@Composable
fun PlaylistDetailScreen(
    navController: NavHostController,
    playlistId: Long,
    viewModel: PlaylistViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val playlist by viewModel.playlist.collectAsState()
    val tracks by viewModel.tracks.collectAsState()

    Column(modifier = Modifier.fillMaxSize().liquidBackground().statusBarsPadding()) {
        Row(modifier = Modifier.padding(16.dp)) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = LarpTextPrimary)
            }
            Text(
                playlist?.name ?: "Playlist",
                style = MaterialTheme.typography.titleLarge,
                color = LarpTextPrimary,
                modifier = Modifier.padding(start = 8.dp, top = 12.dp)
            )
            if (tracks.isNotEmpty()) {
                IconButton(onClick = { playerViewModel.playTrack(tracks.first(), tracks) }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Reproduzir tudo", tint = LarpTextPrimary)
                }
            }
        }

        LazyColumn(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            if (tracks.isEmpty()) {
                item {
                    Text(
                        "Esta playlist está vazia. Adicione músicas pela tela de reprodução.",
                        color = com.larpmusic.app.ui.theme.LarpTextSecondary,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            }
            items(tracks, key = { it.id }) { track ->
                val isFav by playerViewModel.isFavorite(track).collectAsState(initial = false)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    TrackRow(
                        track = track,
                        isFavorite = isFav,
                        onClick = { playerViewModel.playTrack(track, tracks) },
                        onToggleFavorite = { playerViewModel.toggleFavorite(track, !isFav) },
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { viewModel.removeTrack(track) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remover", tint = com.larpmusic.app.ui.theme.LarpTextSecondary)
                    }
                }
            }
        }
    }
}
