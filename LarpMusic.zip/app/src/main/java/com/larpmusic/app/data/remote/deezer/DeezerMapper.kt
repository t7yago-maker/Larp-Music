package com.larpmusic.app.data.remote.deezer

import android.net.Uri
import com.larpmusic.app.data.remote.youtube.StreamUris
import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track

/**
 * Deezer only gives a 30s preview, so the playable URI asks the player to find the FULL song on
 * YouTube (matched by artist + title + duration) and falls back to the preview if that fails.
 */
fun DeezerTrackDto.toDomain(): Track? {
    val tid = id ?: return null
    val name = title?.takeIf { it.isNotBlank() } ?: return null
    val artistName = artist?.name ?: "Artista desconhecido"
    return Track(
        id = tid.toString(),
        source = MusicSource.DEEZER,
        title = name,
        artistName = artistName,
        artistId = artist?.id?.toString() ?: "",
        albumName = album?.title,
        albumId = album?.id?.toString(),
        artworkUrl = album?.coverBig ?: album?.coverMedium,
        streamUrl = StreamUris.match(artistName, name, duration ?: 0, preview),
        durationSeconds = duration ?: 0
    )
}

fun DeezerArtistDto.toDomain(): Artist? {
    val aid = id ?: return null
    return Artist(aid.toString(), MusicSource.DEEZER, name ?: return null, pictureBig ?: pictureMedium)
}

fun DeezerAlbumDto.toDomain(): Album? {
    val aid = id ?: return null
    return Album(aid.toString(), MusicSource.DEEZER, title ?: return null, artist?.name ?: "", coverBig ?: coverMedium)
}
