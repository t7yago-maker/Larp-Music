package com.larpmusic.app.player

import android.content.Context
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Aprende o gosto de quem ouve: cada faixa tocada soma pontos ao artista (e ao termo de gênero
 * do título quando houver). Faixas puladas rápido perdem pontos. O resultado alimenta o
 * "radio infinito" do PlayerController, que continua a fila com músicas do mesmo estilo.
 */
@Singleton
class TasteEngine @Inject constructor(@ApplicationContext context: Context) {
    private val prefs = context.getSharedPreferences("larp_taste", Context.MODE_PRIVATE)
    private val ui = context.getSharedPreferences("larp_ui", Context.MODE_PRIVATE)
    val radioEnabled: Boolean get() = ui.getBoolean("radio", true)

    fun recordPlay(track: Track, listenedMs: Long) {
        val key = "a:" + track.artistName.trim().lowercase()
        val delta = if (listenedMs in 0..15_000) -1f else 1f
        prefs.edit().putFloat(key, (prefs.getFloat(key, 0f) + delta).coerceAtLeast(0f)).apply()
    }

    /** Artistas favoritos em ordem de pontuação. */
    fun topArtists(limit: Int = 5): List<String> = prefs.all
        .filterKeys { it.startsWith("a:") }
        .mapNotNull { (k, v) -> (v as? Float)?.takeIf { it > 0f }?.let { k.removePrefix("a:") to it } }
        .sortedByDescending { it.second }.take(limit).map { it.first }

    /** Consulta de busca para continuar a fila: mistura a faixa atual com o gosto acumulado. */
    fun radioQuery(current: Track): String {
        val top = topArtists(3).filter { !it.equals(current.artistName, true) }
        return if (top.isNotEmpty() && kotlin.random.Random.nextInt(3) > 0)
            top.random() else current.artistName
    }
}
