package com.larpmusic.app.data.remote.deezer

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/** Deezer public API: no key, no login. Used for the mainstream catalog (charts, hits, metadata, covers). */
interface DeezerApi {
    @GET("search")
    suspend fun searchTracks(@Query("q") query: String, @Query("limit") limit: Int = 40): DeezerTracksResponse

    @GET("search/artist")
    suspend fun searchArtists(@Query("q") query: String, @Query("limit") limit: Int = 20): DeezerArtistsResponse

    @GET("search/album")
    suspend fun searchAlbums(@Query("q") query: String, @Query("limit") limit: Int = 30): DeezerAlbumsResponse

    @GET("chart/0/tracks")
    suspend fun chart(@Query("limit") limit: Int = 50): DeezerTracksResponse

    @GET("playlist/{id}/tracks")
    suspend fun playlistTracks(@Path("id") id: Long, @Query("limit") limit: Int = 50): DeezerTracksResponse

    companion object {
        const val BASE_URL = "https://api.deezer.com/"
        const val TOP_BRASIL_PLAYLIST = 1111141961L
    }
}

// Everything nullable: Gson ignores Kotlin defaults.
data class DeezerTracksResponse(val data: List<DeezerTrackDto>?)
data class DeezerArtistsResponse(val data: List<DeezerArtistDto>?)
data class DeezerAlbumsResponse(val data: List<DeezerAlbumDto>?)

data class DeezerArtistDto(
    val id: Long?,
    val name: String?,
    @SerializedName("picture_medium") val pictureMedium: String?,
    @SerializedName("picture_big") val pictureBig: String?
)

data class DeezerAlbumDto(
    val id: Long?,
    val title: String?,
    @SerializedName("cover_medium") val coverMedium: String?,
    @SerializedName("cover_big") val coverBig: String?,
    val artist: DeezerArtistDto?
)

data class DeezerTrackDto(
    val id: Long?,
    val title: String?,
    val duration: Int?,
    val preview: String?,
    val artist: DeezerArtistDto?,
    val album: DeezerAlbumDto?
)
