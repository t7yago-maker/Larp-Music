package com.larpmusic.app.data.repository

import com.larpmusic.app.BuildConfig
import com.larpmusic.app.data.local.db.CachedTrackEntity
import com.larpmusic.app.data.local.db.FavoriteEntity
import com.larpmusic.app.data.local.db.FollowedArtistEntity
import com.larpmusic.app.data.local.db.HistoryEntity
import com.larpmusic.app.data.local.db.TrackCacheDao
import com.larpmusic.app.data.local.db.FavoriteDao
import com.larpmusic.app.data.local.db.FollowedArtistDao
import com.larpmusic.app.data.local.db.HistoryDao
import com.larpmusic.app.data.remote.jamendo.JamendoApi
import com.larpmusic.app.data.remote.jamendo.toDomain
import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

sealed class SourceResult<out T> {
    data class Success<T>(val data: T) : SourceResult<T>()
    data class Error(val message: String) : SourceResult<Nothing>()
    /** Jamendo is wired up in code but JAMENDO_CLIENT_ID was not provided at build time. */
    object NotConfigured : SourceResult<Nothing>()
}

/**
 * Single entry point for all music catalog data. Today it talks to Jamendo only; a second
 * source (Audius, SoundCloud) plugs in by adding another branch here and in
 * [com.larpmusic.app.domain.model.MusicSource] without touching the UI layer — that's the
 * "modular source" architecture the spec asks for.
 *
 * Every result is honest about where it came from: nothing is invented when the client id
 * is missing or a call fails, per the project's no-fake-data rule.
 */
@Singleton
class MusicRepository @Inject constructor(
    private val jamendoApi: JamendoApi,
    private val trackCacheDao: TrackCacheDao,
    private val favoriteDao: FavoriteDao,
    private val followedArtistDao: FollowedArtistDao,
    private val historyDao: HistoryDao
) {
    private val clientId = BuildConfig.JAMENDO_CLIENT_ID
    private val configured get() = clientId.isNotBlank()

    suspend fun searchTracks(query: String): SourceResult<List<Track>> {
        if (!configured) return SourceResult.NotConfigured
        return runCatching {
            val tracks = jamendoApi.searchTracks(clientId, query = query).results.mapNotNull { it.toDomain() }
            cacheTracks(tracks)
            tracks
        }.fold(
            onSuccess = { SourceResult.Success(it) },
            onFailure = { SourceResult.Error(it.message ?: "Falha na busca Jamendo") }
        )
    }

    suspend fun searchArtists(query: String): SourceResult<List<Artist>> {
        if (!configured) return SourceResult.NotConfigured
        return runCatching {
            jamendoApi.searchArtists(clientId, query = query).results.map { it.toDomain() }
        }.fold(
            onSuccess = { SourceResult.Success(it) },
            onFailure = { SourceResult.Error(it.message ?: "Falha na busca de artistas") }
        )
    }

    suspend fun searchAlbums(query: String): SourceResult<List<Album>> {
        if (!configured) return SourceResult.NotConfigured
        return runCatching {
            jamendoApi.searchAlbums(clientId, query = query).results.map { it.toDomain() }
        }.fold(
            onSuccess = { SourceResult.Success(it) },
            onFailure = { SourceResult.Error(it.message ?: "Falha na busca de álbuns") }
        )
    }

    suspend fun popularTracks(): SourceResult<List<Track>> {
        if (!configured) return SourceResult.NotConfigured
        return runCatching {
            val tracks = jamendoApi.popularTracks(clientId).results.mapNotNull { it.toDomain() }
            cacheTracks(tracks)
            tracks
        }.fold(
            onSuccess = { SourceResult.Success(it) },
            onFailure = { SourceResult.Error(it.message ?: "Falha ao carregar músicas em alta") }
        )
    }

    suspend fun newReleases(): SourceResult<List<Track>> {
        if (!configured) return SourceResult.NotConfigured
        return runCatching {
            val tracks = jamendoApi.newReleases(clientId).results.mapNotNull { it.toDomain() }
            cacheTracks(tracks)
            tracks
        }.fold(
            onSuccess = { SourceResult.Success(it) },
            onFailure = { SourceResult.Error(it.message ?: "Falha ao carregar lançamentos") }
        )
    }

    fun isConfigured() = configured

    private suspend fun cacheTracks(tracks: List<Track>) {
        trackCacheDao.upsertAll(tracks.map { it.toCacheEntity() })
    }

    suspend fun recordPlay(track: Track) {
        cacheTracks(listOf(track))
        historyDao.record(HistoryEntity(source = track.source.name, remoteId = track.id))
    }

    fun recentlyPlayed(): Flow<List<Track>> =
        historyDao.recentlyPlayed().map { list -> list.map { it.toDomainWithFavorite() } }

    fun favorites(): Flow<List<Track>> =
        favoriteDao.favoriteTracks().map { list -> list.map { it.toDomain().copy(isFavorite = true) } }

    suspend fun toggleFavorite(track: Track, favorite: Boolean) {
        if (favorite) {
            cacheTracks(listOf(track))
            favoriteDao.add(FavoriteEntity(track.source.name, track.id))
        } else {
            favoriteDao.remove(track.source.name, track.id)
        }
    }

    fun isFavorite(track: Track): Flow<Boolean> = favoriteDao.isFavorite(track.source.name, track.id)

    fun followedArtists(): Flow<List<Artist>> = followedArtistDao.followedArtists().map { list ->
        list.map { Artist(it.remoteId, MusicSource.valueOf(it.source), it.name, it.imageUrl) }
    }

    suspend fun followArtist(artist: Artist, follow: Boolean) {
        if (follow) {
            followedArtistDao.follow(
                FollowedArtistEntity(artist.source.name, artist.id, artist.name, artist.imageUrl)
            )
        } else {
            followedArtistDao.unfollow(artist.source.name, artist.id)
        }
    }

    fun isFollowingArtist(artist: Artist): Flow<Boolean> =
        followedArtistDao.isFollowing(artist.source.name, artist.id)

    private fun Track.toCacheEntity() = CachedTrackEntity(
        source = source.name,
        remoteId = id,
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomain() = Track(
        id = remoteId,
        source = MusicSource.valueOf(source),
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomainWithFavorite() = toDomain()
}
