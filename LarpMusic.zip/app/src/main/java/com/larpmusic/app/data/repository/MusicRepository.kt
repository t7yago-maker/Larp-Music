package com.larpmusic.app.data.repository

import com.larpmusic.app.BuildConfig
import com.larpmusic.app.data.local.db.CachedTrackEntity
import com.larpmusic.app.data.local.db.FavoriteEntity
import com.larpmusic.app.data.local.db.FollowedArtistEntity
import com.larpmusic.app.data.local.db.HistoryEntity
import com.larpmusic.app.data.local.db.TrackCacheDao
import com.larpmusic.app.data.local.db.FavoriteDao
import com.larpmusic.app.data.local.db.FollowedArtistDao
import com.larpmusic.app.data.local.db.HistoryDao
import com.larpmusic.app.data.remote.deezer.DeezerApi
import com.larpmusic.app.data.remote.deezer.toDomain
import com.larpmusic.app.data.remote.youtube.YoutubeSource
import com.larpmusic.app.data.remote.jamendo.JamendoApi
import com.larpmusic.app.data.remote.jamendo.toDomain
import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

sealed class SourceResult<out T> {
    data class Success<T>(val data: T) : SourceResult<T>()
    data class Error(val message: String) : SourceResult<Nothing>()
    /** Kept for UI compatibility; no longer returned because Audius needs no configuration. */
    object NotConfigured : SourceResult<Nothing>()
}

/**
 * Single entry point for all music catalog data.
 *  - Deezer  : mainstream catalog (charts, hits, covers, metadata). Plays the FULL song by matching it on YouTube
 *              (30s preview as fallback).
 *  - YouTube : YouTube Music songs, played in full. Covers what Deezer lacks (funk automotivo, remixes, etc.).
 *  - Jamendo : optional extra, only if JAMENDO_CLIENT_ID was provided at build time.
 * If a source fails the others still answer; an Error is only returned when every source failed.
 */
@Singleton
class MusicRepository @Inject constructor(
    private val deezerApi: DeezerApi,
    private val youtube: YoutubeSource,
    private val jamendoApi: JamendoApi,
    private val trackCacheDao: TrackCacheDao,
    private val favoriteDao: FavoriteDao,
    private val followedArtistDao: FollowedArtistDao,
    private val historyDao: HistoryDao
) {
    private val jamendoId = BuildConfig.JAMENDO_CLIENT_ID
    private val jamendoOn get() = jamendoId.isNotBlank()

    /** Search text used for each Explore chip. */
    private val genreQueries = mapOf(
        "automotivo" to "funk automotivo",
        "funk" to "funk brasil",
        "sertanejo" to "sertanejo",
        "trap" to "trap brasil",
        "pagode" to "pagode",
        "rap" to "rap nacional",
        "pop" to "pop hits",
        "rock" to "rock",
        "eletrônica" to "electronic dance",
        "reggaeton" to "reggaeton"
    )

    private suspend fun <T> catalog(
        failMessage: String,
        sources: List<suspend () -> List<T>>
    ): SourceResult<List<T>> = coroutineScope {
        val results = sources.map { src -> async { runCatching { src() } } }.map { it.await() }
        val lists = results.mapNotNull { it.getOrNull() }.filter { it.isNotEmpty() }
        val anyOk = results.any { it.isSuccess }
        when {
            lists.isNotEmpty() -> SourceResult.Success(interleave(lists))
            anyOk -> SourceResult.Success(emptyList())
            else -> SourceResult.Error(
                results.firstNotNullOfOrNull { it.exceptionOrNull() }
                    ?.let { "$failMessage: ${it.message ?: "sem conexão"}" } ?: failMessage
            )
        }
    }

    private fun <T> interleave(lists: List<List<T>>): List<T> {
        val out = ArrayList<T>()
        var i = 0
        while (lists.any { i < it.size }) {
            lists.forEach { if (i < it.size) out.add(it[i]) }
            i++
        }
        return out
    }

    /** Same song from two sources: keep the first one. */
    private fun List<Track>.dedupe(): List<Track> {
        val seen = HashSet<String>()
        fun norm(t: Track) = (t.artistName + "|" + t.title).lowercase()
            .replace(Regex("\\(.*?\\)|\\[.*?]"), "").replace(Regex("[^\\p{L}\\p{N}|]"), "")
        return filter { seen.add(norm(it)) }
    }

    private suspend fun SourceResult<List<Track>>.cached(): SourceResult<List<Track>> {
        if (this is SourceResult.Success) {
            val d = data.dedupe()
            cacheTracks(d)
            return SourceResult.Success(d)
        }
        return this
    }

    private fun jamendo(block: suspend () -> List<Track>): List<suspend () -> List<Track>> =
        if (jamendoOn) listOf(block) else emptyList()

    suspend fun searchTracks(query: String): SourceResult<List<Track>> = catalog(
        "Falha na busca",
        listOf<suspend () -> List<Track>>(
            { deezerApi.searchTracks(query).data.orEmpty().mapNotNull { it.toDomain() } },
            { youtube.searchSongs(query) }
        ) + jamendo { jamendoApi.searchTracks(jamendoId, query = query).results.mapNotNull { it.toDomain() } }
    ).cached()

    suspend fun searchArtists(query: String): SourceResult<List<Artist>> = catalog(
        "Falha na busca de artistas",
        listOf<suspend () -> List<Artist>>(
            { deezerApi.searchArtists(query).data.orEmpty().mapNotNull { it.toDomain() } }
        ) + (if (jamendoOn) listOf<suspend () -> List<Artist>>(
            { jamendoApi.searchArtists(jamendoId, query = query).results.map { it.toDomain() } }
        ) else emptyList())
    )

    suspend fun searchAlbums(query: String): SourceResult<List<Album>> = catalog(
        "Falha na busca de álbuns",
        listOf<suspend () -> List<Album>>(
            { deezerApi.searchAlbums(query).data.orEmpty().mapNotNull { it.toDomain() } }
        ) + (if (jamendoOn) listOf<suspend () -> List<Album>>(
            { jamendoApi.searchAlbums(jamendoId, query = query).results.map { it.toDomain() } }
        ) else emptyList())
    )

    suspend fun popularTracks(): SourceResult<List<Track>> = catalog(
        "Falha ao carregar músicas em alta",
        listOf<suspend () -> List<Track>>(
            {
                runCatching { deezerApi.playlistTracks(DeezerApi.TOP_BRASIL_PLAYLIST) }
                    .getOrElse { deezerApi.chart() }
                    .data.orEmpty().mapNotNull { it.toDomain() }
            },
            { youtube.searchSongs("funk automotivo") }
        ) + jamendo { jamendoApi.popularTracks(jamendoId).results.mapNotNull { it.toDomain() } }
    ).cached()

    suspend fun newReleases(): SourceResult<List<Track>> = catalog(
        "Falha ao carregar lançamentos",
        listOf<suspend () -> List<Track>>(
            { deezerApi.chart().data.orEmpty().mapNotNull { it.toDomain() } },
            { youtube.searchSongs("lançamentos 2026") }
        ) + jamendo { jamendoApi.newReleases(jamendoId).results.mapNotNull { it.toDomain() } }
    ).cached()

    /** Tracks for one Explore genre chip. */
    suspend fun tracksByGenre(genre: String): SourceResult<List<Track>> {
        val q = genreQueries[genre] ?: genre
        return catalog(
            "Falha ao carregar o gênero",
            listOf<suspend () -> List<Track>>(
                { youtube.searchSongs(q) },
                { deezerApi.searchTracks(q).data.orEmpty().mapNotNull { it.toDomain() } }
            )
        ).cached()
    }

    fun isConfigured() = true

    private suspend fun cacheTracks(tracks: List<Track>) {
        trackCacheDao.upsertAll(tracks.map { it.toCacheEntity() })
    }

    suspend fun recordPlay(track: Track) {
        cacheTracks(listOf(track))
        historyDao.record(HistoryEntity(source = track.source.name, remoteId = track.id))
    }

    fun recentlyPlayed(): Flow<List<Track>> =
        historyDao.recentlyPlayed().map { list -> list.map { it.toDomainWithFavorite() } }

    fun favorites(): Flow<List<Track>> =
        favoriteDao.favoriteTracks().map { list -> list.map { it.toDomain().copy(isFavorite = true) } }

    suspend fun toggleFavorite(track: Track, favorite: Boolean) {
        if (favorite) {
            cacheTracks(listOf(track))
            favoriteDao.add(FavoriteEntity(track.source.name, track.id))
        } else {
            favoriteDao.remove(track.source.name, track.id)
        }
    }

    fun isFavorite(track: Track): Flow<Boolean> = favoriteDao.isFavorite(track.source.name, track.id)

    fun followedArtists(): Flow<List<Artist>> = followedArtistDao.followedArtists().map { list ->
        list.map { Artist(it.remoteId, MusicSource.valueOf(it.source), it.name, it.imageUrl) }
    }

    suspend fun followArtist(artist: Artist, follow: Boolean) {
        if (follow) {
            followedArtistDao.follow(
                FollowedArtistEntity(artist.source.name, artist.id, artist.name, artist.imageUrl)
            )
        } else {
            followedArtistDao.unfollow(artist.source.name, artist.id)
        }
    }

    fun isFollowingArtist(artist: Artist): Flow<Boolean> =
        followedArtistDao.isFollowing(artist.source.name, artist.id)

    private fun Track.toCacheEntity() = CachedTrackEntity(
        source = source.name,
        remoteId = id,
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomain() = Track(
        id = remoteId,
        source = MusicSource.valueOf(source),
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomainWithFavorite() = toDomain()
}
