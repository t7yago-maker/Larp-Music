package com.larpmusic.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.larpmusic.app.ui.auth.LoginScreen
import com.larpmusic.app.ui.auth.RegisterScreen
import com.larpmusic.app.ui.explore.ExploreScreen
import com.larpmusic.app.ui.home.HomeScreen
import com.larpmusic.app.ui.library.LibraryScreen
import com.larpmusic.app.ui.player.PlayerScreen
import com.larpmusic.app.ui.playlist.PlaylistDetailScreen
import com.larpmusic.app.ui.profile.ProfileScreen
import com.larpmusic.app.ui.search.SearchScreen
import com.larpmusic.app.ui.settings.SettingsScreen

@Composable
fun LarpNavGraph(navController: NavHostController, startDestination: String) {
    val player = Screen.Player.route
    NavHost(
        navController = navController,
        startDestination = startDestination,
        enterTransition = {
            if (targetState.destination.route == player)
                slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300))
            else fadeIn(tween(320)) + scaleIn(tween(320, easing = FastOutSlowInEasing), initialScale = 0.96f)
        },
        exitTransition = {
            if (targetState.destination.route == player) fadeOut(tween(300)) + scaleOut(tween(300), targetScale = 0.94f)
            else fadeOut(tween(220))
        },
        popEnterTransition = { fadeIn(tween(320)) + scaleIn(tween(320, easing = FastOutSlowInEasing), initialScale = 0.94f) },
        popExitTransition = {
            if (initialState.destination.route == player)
                slideOutVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(300))
            else fadeOut(tween(220))
        }
    ) {
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.Register.route) { RegisterScreen(navController) }

        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Explore.route) { ExploreScreen(navController) }
        composable(Screen.Search.route) { SearchScreen(navController) }
        composable(Screen.Library.route) { LibraryScreen(navController) }
        composable(Screen.Profile.route) { ProfileScreen(navController) }

        composable(Screen.Player.route) { PlayerScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }

        composable(
            route = Screen.PlaylistDetail.route,
            arguments = listOf(navArgument("playlistId") { type = NavType.LongType })
        ) { backStackEntry ->
            val playlistId = backStackEntry.arguments?.getLong("playlistId") ?: 0L
            PlaylistDetailScreen(navController, playlistId)
        }
    }
}
