package com.larpmusic.app.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.domain.model.EqualizerPreset
import com.larpmusic.app.domain.model.Track
import com.larpmusic.app.player.EqualizerManager
import com.larpmusic.app.player.PlaybackUiState
import com.larpmusic.app.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Thin, app-wide adapter between the singleton [PlayerController] (bound to the background
 * playback service) and Compose. Shared by the mini-player, the expanded player screen and the
 * bottom-nav scaffold so there is exactly one source of truth for "what's playing".
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val playerController: PlayerController,
    private val musicRepository: MusicRepository,
    private val equalizerManager: EqualizerManager
) : ViewModel() {

    val playbackState: StateFlow<PlaybackUiState> = playerController.state

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    init {
        playerController.connect()
        viewModelScope.launch {
            while (true) {
                _positionMs.value = playerController.currentPositionMs()
                delay(500)
            }
        }
    }

    fun playTrack(track: Track, queue: List<Track> = listOf(track)) {
        val index = queue.indexOfFirst { it.id == track.id && it.source == track.source }.coerceAtLeast(0)
        playerController.playQueue(queue, index)
        viewModelScope.launch { musicRepository.recordPlay(track) }
    }

    fun togglePlayPause() = playerController.togglePlayPause()
    fun next() = playerController.skipToNext()
    fun previous() = playerController.skipToPrevious()
    fun seekTo(ms: Long) = playerController.seekTo(ms)
    fun setShuffle(enabled: Boolean) = playerController.setShuffle(enabled)
    fun cycleRepeat() = playerController.cycleRepeatMode()

    fun toggleFavorite(track: Track, favorite: Boolean) {
        viewModelScope.launch { musicRepository.toggleFavorite(track, favorite) }
    }

    fun isFavorite(track: Track) = musicRepository.isFavorite(track)

    fun applyEqualizerPreset(preset: EqualizerPreset) = equalizerManager.applyPreset(preset)

    override fun onCleared() {
        super.onCleared()
        playerController.disconnect()
    }
}
