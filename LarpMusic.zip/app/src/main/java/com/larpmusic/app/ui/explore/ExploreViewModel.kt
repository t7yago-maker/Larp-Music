package com.larpmusic.app.ui.explore

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.data.repository.SourceResult
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

val exploreGenres = listOf("automotivo", "funk", "sertanejo", "trap", "pagode", "rap", "pop", "rock", "eletrônica", "reggaeton")

data class ExploreUiState(
    val selectedGenre: String? = null,
    val tracks: List<Track> = emptyList(),
    val loading: Boolean = false,
    val sourceConfigured: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class ExploreViewModel @Inject constructor(private val musicRepository: MusicRepository) : ViewModel() {

    private val _state = MutableStateFlow(ExploreUiState())
    val state: StateFlow<ExploreUiState> = _state.asStateFlow()

    fun selectGenre(genre: String) {
        _state.value = _state.value.copy(selectedGenre = genre, loading = true, error = null)
        viewModelScope.launch {
            when (val result = musicRepository.tracksByGenre(genre)) {
                is SourceResult.Success -> _state.value = _state.value.copy(loading = false, tracks = result.data, sourceConfigured = true)
                is SourceResult.Error -> _state.value = _state.value.copy(loading = false, error = result.message)
                SourceResult.NotConfigured -> _state.value = _state.value.copy(loading = false, sourceConfigured = false)
            }
        }
    }
}
