package com.larpmusic.app.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.larpmusic.app.domain.model.RepeatMode
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

data class PlaybackUiState(
    val currentTrack: Track? = null,
    val queue: List<Track> = emptyList(),
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val isBuffering: Boolean = false,
    val error: String? = null
)

/**
 * UI-facing handle to playback. The real ExoPlayer lives in [PlaybackService]; this class binds a
 * single, app-lifetime [MediaController] to it.
 *
 * Important: this is a @Singleton and the connection is NEVER torn down by a ViewModel. (The old
 * version called disconnect() from PlayerViewModel.onCleared(); since every screen has its own
 * PlayerViewModel, simply changing tab killed the controller and every button stopped working.)
 */
@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val musicRepository: com.larpmusic.app.data.repository.MusicRepository,
    private val taste: TasteEngine
) {
    private var trackStartedAt = 0L
    private var radioJob: Job? = null


    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private var controller: MediaController? = null
    private var connecting = false
    private var queueTracks: List<Track> = emptyList()
    private var pendingPlay: Pair<List<Track>, Int>? = null
    private var progressJob: Job? = null

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            connecting = false
            runCatching { future.get() }
                .onSuccess { c ->
                    controller = c
                    attachListener(c)
                    pendingPlay?.let { (tracks, index) ->
                        pendingPlay = null
                        startQueue(c, tracks, index)
                    }
                }
                .onFailure {
                    _state.value = _state.value.copy(error = "Não foi possível iniciar o player.")
                }
        }, MoreExecutors.directExecutor())
    }

    fun playQueue(tracks: List<Track>, startIndex: Int) {
        if (tracks.isEmpty()) return
        val index = startIndex.coerceIn(0, tracks.lastIndex)
        // Show the track immediately; the audio starts as soon as the controller is ready.
        _state.value = _state.value.copy(queue = tracks, currentTrack = tracks[index], error = null, positionMs = 0L)
        _positionMs.value = 0L
        val c = controller
        if (c == null) {
            pendingPlay = tracks to index
            connect()
        } else {
            startQueue(c, tracks, index)
        }
    }

    private fun startQueue(c: MediaController, tracks: List<Track>, index: Int) {
        queueTracks = tracks
        c.setMediaItems(tracks.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying || c.playWhenReady) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (c.playbackState == Player.STATE_ENDED) c.seekTo(0)
            c.play()
        }
    }

    fun skipToNext() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
    }

    fun skipToPrevious() {
        val c = controller ?: return
        // Standard behaviour: restart the song if we're past 3s, otherwise go to the previous one.
        if (c.currentPosition > 3000 || !c.hasPreviousMediaItem()) c.seekTo(0) else c.seekToPreviousMediaItem()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
        _positionMs.value = positionMs
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
        _state.value = _state.value.copy(shuffleEnabled = enabled)
    }

    fun cycleRepeatMode() {
        val next = when (_state.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        controller?.repeatMode = when (next) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
        _state.value = _state.value.copy(repeatMode = next)
    }

    private fun startProgressUpdates() {
        if (progressJob?.isActive == true) return
        progressJob = scope.launch {
            while (isActive) {
                controller?.let { _positionMs.value = it.currentPosition.coerceAtLeast(0L) }
                delay(500)
            }
        }
    }

    private fun stopProgressUpdates() {
        progressJob?.cancel()
        progressJob = null
        controller?.let { _positionMs.value = it.currentPosition.coerceAtLeast(0L) }
    }

    private fun attachListener(c: MediaController) {
        // Sync with whatever the service is already playing (e.g. app reopened from notification).
        if (c.mediaItemCount > 0) {
            _state.value = _state.value.copy(
                isPlaying = c.isPlaying,
                durationMs = c.duration.coerceAtLeast(0L),
                shuffleEnabled = c.shuffleModeEnabled
            )
            if (c.isPlaying) startProgressUpdates()
        }
        c.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.value = _state.value.copy(isPlaying = isPlaying)
                if (isPlaying) startProgressUpdates() else stopProgressUpdates()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _state.value = _state.value.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = c.duration.coerceAtLeast(0L)
                )
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val prev = _state.value.currentTrack
                if (prev != null && trackStartedAt > 0L) {
                    taste.recordPlay(prev, System.currentTimeMillis() - trackStartedAt)
                }
                trackStartedAt = System.currentTimeMillis()
                val track = queueTracks.getOrNull(c.currentMediaItemIndex) ?: _state.value.currentTrack
                track?.let { extendQueueWithSimilar(c, it) }
                _positionMs.value = 0L
                _state.value = _state.value.copy(
                    currentTrack = track,
                    durationMs = c.duration.coerceAtLeast(0L).takeIf { it > 0 }
                        ?: ((track?.durationSeconds ?: 0) * 1000L)
                )
            }

            override fun onPlayerError(error: PlaybackException) {
                _state.value = _state.value.copy(
                    isBuffering = false,
                    error = "Não foi possível tocar esta faixa. Pulando para a próxima…"
                )
                // A single dead stream must not freeze the queue.
                if (c.hasNextMediaItem()) {
                    c.seekToNextMediaItem()
                    c.prepare()
                    c.play()
                }
            }
        })
    }

    /** Radio infinito: quando restam <=2 faixas, busca músicas parecidas com o gosto da pessoa. */
    private fun extendQueueWithSimilar(c: MediaController, current: Track) {
        if (!taste.radioEnabled || c.mediaItemCount - c.currentMediaItemIndex > 2 || radioJob?.isActive == true) return
        radioJob = scope.launch {
            val res = musicRepository.searchTracks(taste.radioQuery(current))
            val found = (res as? com.larpmusic.app.data.repository.SourceResult.Success)?.data ?: return@launch
            val known = queueTracks.map { it.source to it.id }.toSet()
            val fresh = found.filter { (it.source to it.id) !in known }.shuffled().take(8)
            if (fresh.isEmpty()) return@launch
            queueTracks = queueTracks + fresh
            c.addMediaItems(fresh.map { it.toMediaItem() })
            _state.value = _state.value.copy(queue = queueTracks)
        }
    }

    private fun Track.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId("${source.name}:$id")
        .setUri(streamUrl)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artistName)
                .setAlbumTitle(albumName)
                .setArtworkUri(artworkUrl?.let { Uri.parse(it) })
                .build()
        )
        .build()
}
