package com.larpmusic.app.ui.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import coil.compose.AsyncImage
import com.larpmusic.app.ui.auth.AuthViewModel
import com.larpmusic.app.ui.auth.fieldColors
import com.larpmusic.app.ui.components.AppScaffold
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.navigation.Screen
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpBackground
import com.larpmusic.app.ui.components.LiquidButton
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

@Composable
fun ProfileScreen(
    navController: NavHostController,
    authViewModel: AuthViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val state by authViewModel.state.collectAsState()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    var displayName by remember(state.user?.id) { mutableStateOf(state.user?.displayName ?: "") }
    var bio by remember(state.user?.id) { mutableStateOf(state.user?.bio ?: "") }
    var editing by remember { mutableStateOf(false) }

    LaunchedEffect(state.user) {
        if (state.user == null) {
            navController.navigate(Screen.Login.route) { popUpTo(0) }
        }
    }

    val user = state.user ?: return

    AppScaffold(navController, currentRoute, playerViewModel) { bottomPadding ->
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = bottomPadding.dp)) {
            item {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    AsyncImage(
                        model = user.avatarUrl,
                        contentDescription = null,
                        modifier = Modifier.size(96.dp).clip(CircleShape)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(user.displayName, style = MaterialTheme.typography.headlineMedium, color = LarpTextPrimary)
                    Text("@${user.username}", style = MaterialTheme.typography.bodyMedium, color = LarpTextSecondary)
                }
            }

            item { Spacer(Modifier.height(24.dp)) }

            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        if (editing) {
                            OutlinedTextField(displayName, { displayName = it }, label = { Text("Nome de exibição") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(bio, { bio = it }, label = { Text("Descrição") }, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                            Spacer(Modifier.height(12.dp))
                            LiquidButton("Salvar", { authViewModel.updateProfile(displayName, bio, user.avatarUrl); editing = false })
                        } else {
                            Text(user.bio ?: "Nenhuma descrição ainda.", color = LarpTextSecondary)
                            Spacer(Modifier.height(12.dp))
                            LiquidButton("Editar perfil", { editing = true })
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(16.dp)) }

            item {
                LiquidButton("Configurações e sons", { navController.navigate(Screen.Settings.route) }, Modifier.fillMaxWidth(), fillWidth = true)
            }

            item { Spacer(Modifier.height(12.dp)) }

            item {
                LiquidButton("Sair", { authViewModel.logout { navController.navigate(Screen.Login.route) { popUpTo(0) } } }, Modifier.fillMaxWidth(), fillWidth = true)
            }

            item { Spacer(Modifier.height(12.dp)) }

            item {
                var confirmDelete by remember { mutableStateOf(false) }
                LiquidButton("Excluir conta", { confirmDelete = true }, Modifier.fillMaxWidth(), fillWidth = true, textColor = MaterialTheme.colorScheme.error)
                if (confirmDelete) {
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = { confirmDelete = false },
                        title = { Text("Excluir conta?") },
                        text = { Text("Isso apaga sua conta e sessões locais permanentemente. Não pode ser desfeito.") },
                        confirmButton = {
                            androidx.compose.material3.TextButton(onClick = {
                                authViewModel.deleteAccount { navController.navigate(Screen.Login.route) { popUpTo(0) } }
                            }) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
                        },
                        dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
                    )
                }
            }
        }
    }
}
