package com.larpmusic.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.draw.alpha
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.larpmusic.app.ui.theme.LarpTextPrimary

/**
 * Fundo "vidro líquido": base cinza claro-escuro com manchas brancas desfocadas que derivam
 * devagar (como no vídeo de referência) e um toque rosado no canto inferior direito.
 */
fun Modifier.liquidBackground(): Modifier = composed {
    val t = rememberInfiniteTransition(label = "liquid")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    drawBehind {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF5A5A62), Color(0xFF3C3C42), Color(0xFF2E2E34))))
        fun blob(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        blob(w * (0.25f + 0.35f * a), h * (0.18f + 0.10f * b), w * 0.85f, Color(0x66FFFFFF))
        blob(w * (0.80f - 0.30f * b), h * (0.45f + 0.12f * a), w * 0.70f, Color(0x4DF2F2F6))
        blob(w * (0.20f + 0.25f * b), h * (0.70f - 0.10f * a), w * 0.60f, Color(0x40FFFFFF))
        blob(w * 0.92f, h * (0.90f - 0.06f * a), w * 0.65f, Color(0x55B05A70))
    }
}

/** Botão de vidro líquido: pílula translúcida com brilho e efeito de "apertar" ao tocar. */
@Composable
fun LiquidButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    fillWidth: Boolean = false,
    textColor: Color = LarpTextPrimary
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, label = "press")
    GlassSurface(
        modifier = modifier.scale(s).alpha(if (enabled) 1f else 0.45f).then(if (fillWidth) Modifier.fillMaxWidth() else Modifier)
            .height(52.dp).clickable(src, null, enabled = enabled) { onClick() },
        shape = RoundedCornerShape(26.dp),
        strong = true
    ) {
        Row(
            modifier = Modifier.then(if (fillWidth) Modifier.fillMaxWidth() else Modifier).padding(horizontal = 28.dp).height(52.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text, color = textColor, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        }
    }
}

/** Animação de entrada "janela": surge com fade, sobe suavemente e cresce de 94% a 100%. */
fun Modifier.appear(delayMs: Int = 0): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(450, delayMillis = delayMs, easing = FastOutSlowInEasing)) }
    graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 48f
        val sc = 0.94f + 0.06f * a.value
        scaleX = sc; scaleY = sc
    }
}
