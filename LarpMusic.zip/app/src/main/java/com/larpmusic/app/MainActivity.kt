package com.larpmusic.app

import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import com.larpmusic.app.ui.components.SoundFx
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.rememberNavController
import com.larpmusic.app.ui.auth.AuthViewModel
import com.larpmusic.app.ui.navigation.LarpNavGraph
import com.larpmusic.app.ui.navigation.Screen
import com.larpmusic.app.ui.theme.LarpMusicTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private lateinit var tapDetector: GestureDetector

    // Som relaxante em TODO toque do app (botões, abas, itens), sem precisar editar tela por tela.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        tapDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SoundFx.init(applicationContext)
        tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { SoundFx.play(); return false }
        })
        // Android 13+: without this the media notification / lock-screen controls never show.
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        setContent {
            LarpMusicTheme {
                LarpRoot()
            }
        }
    }
}

/**
 * Resolves whether a local session already exists before picking the first screen, so a
 * returning user never flashes the login screen (spec: real auth with persisted sessions).
 */
@Composable
private fun LarpRoot() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = hiltViewModel()
    val authState by authViewModel.state.collectAsState()
    var resolvedStart by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(authState.sessionResolved) {
        if (authState.sessionResolved && resolvedStart == null) {
            resolvedStart = if (authState.user != null) Screen.Home.route else Screen.Login.route
        }
    }

    resolvedStart?.let { start ->
        LarpNavGraph(navController = navController, startDestination = start)
    }
}
