package com.larpmusic.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.larpmusic.app.domain.model.EqualizerPreset
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.theme.LarpBackground
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize

@Composable
fun SettingsScreen(navController: NavHostController, viewModel: SettingsViewModel = hiltViewModel()) {
    val settings by viewModel.settings.collectAsState()
    val bandCount = viewModel.bandCount()

    Column(modifier = Modifier.fillMaxSize().background(LarpBackground)) {
        Row(modifier = Modifier.padding(16.dp)) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null, tint = LarpTextPrimary)
            }
            Text("Configurações de áudio", style = MaterialTheme.typography.titleLarge, color = LarpTextPrimary, modifier = Modifier.padding(start = 8.dp, top = 12.dp))
        }

        LazyColumn(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
            item {
                Text("Equalizador", style = MaterialTheme.typography.titleMedium, color = LarpTextPrimary, modifier = Modifier.padding(bottom = 8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(EqualizerPreset.entries.filter { it != EqualizerPreset.CUSTOM }) { preset ->
                        GlassCard(
                            strong = preset == settings.equalizerPreset,
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.clickable { viewModel.selectPreset(preset) }
                        ) {
                            Text(preset.label, color = if (preset == settings.equalizerPreset) LarpTextPrimary else LarpTextSecondary, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            if (bandCount == 0) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Toque uma música para ativar o equalizador — ele atua sobre a sessão de áudio em reprodução.",
                            color = LarpTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column {
                            val freqs = viewModel.centerFrequencies()
                            (0 until bandCount).forEach { band ->
                                var level by remember(band) { mutableFloatStateOf(viewModel.currentLevels().getOrElse(band) { 0 }.toFloat()) }
                                Text("${freqs.getOrNull(band) ?: ""} Hz", color = LarpTextSecondary, style = MaterialTheme.typography.bodySmall)
                                Slider(
                                    value = level,
                                    onValueChange = {
                                        level = it
                                        viewModel.setCustomBandLevel(band, it.toInt())
                                    },
                                    valueRange = viewModel.minLevel().toFloat()..viewModel.maxLevel().toFloat(),
                                    colors = SliderDefaults.colors(thumbColor = LarpTextPrimary, activeTrackColor = LarpTextPrimary)
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(20.dp)) }

            item {
                SettingSwitchRow("Normalização de volume", settings.volumeNormalization, viewModel::setVolumeNormalization)
                SettingSwitchRow("Reprodução contínua (gapless)", settings.gaplessPlayback, viewModel::setGapless)
                SettingSwitchRow("Economia de dados", settings.dataSaver, viewModel::setDataSaver)
            }

            item {
                Spacer(Modifier.height(12.dp))
                Text("Crossfade: ${settings.crossfadeSeconds}s", color = LarpTextPrimary, style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = settings.crossfadeSeconds.toFloat(),
                    onValueChange = { viewModel.setCrossfade(it.toInt()) },
                    valueRange = 0f..12f,
                    steps = 11,
                    colors = SliderDefaults.colors(thumbColor = LarpTextPrimary, activeTrackColor = LarpTextPrimary)
                )
            }

            item {
                Spacer(Modifier.height(12.dp))
                Text(
                    if (settings.sleepTimerMinutes == 0) "Temporizador de desligamento: desativado" else "Temporizador: ${settings.sleepTimerMinutes} min",
                    color = LarpTextPrimary, style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = settings.sleepTimerMinutes.toFloat(),
                    onValueChange = { viewModel.setSleepTimer(it.toInt()) },
                    valueRange = 0f..90f,
                    steps = 8,
                    colors = SliderDefaults.colors(thumbColor = LarpTextPrimary, activeTrackColor = LarpTextPrimary)
                )
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
private fun SettingSwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = LarpTextPrimary, style = MaterialTheme.typography.bodyLarge)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = LarpBackground, checkedTrackColor = LarpTextPrimary)
        )
    }
}
