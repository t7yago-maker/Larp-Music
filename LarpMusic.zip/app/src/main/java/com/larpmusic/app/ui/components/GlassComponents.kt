package com.larpmusic.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.larpmusic.app.ui.theme.LarpGlassBorder
import com.larpmusic.app.ui.theme.LarpGlassFill
import com.larpmusic.app.ui.theme.LarpGlassFillStrong

/**
 * The single building block behind every panel, card, modal, nav bar and control in the app
 * (spec section 1): a translucent, neutral, bordered surface over a blurred backdrop.
 *
 * True backdrop blur (sampling what's actually behind the surface) requires Android 12+
 * (RenderEffect). Below that, [Modifier.blur] is a documented no-op in Compose — the surface
 * still reads as "glass" through translucency and a delicate border, it just isn't blurred on
 * API < 31. That's an intentional, documented platform limitation, not a missing feature.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    strong: Boolean = false,
    bordered: Boolean = true,
    blurRadius: androidx.compose.ui.unit.Dp = 20.dp,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    content: @Composable () -> Unit
) {
    val fill = if (strong) LarpGlassFillStrong else LarpGlassFill
    Box(
        modifier = modifier
            .clip(shape)
            .blur(blurRadius)
            .background(Brush.verticalGradient(listOf(fill, fill.copy(alpha = fill.alpha * 0.65f))))
            .then(if (bordered) Modifier.border(1.dp, LarpGlassBorder, shape) else Modifier)
            .padding(contentPadding)
    ) {
        content()
    }
}

/** Glass panel with visible border and default content padding — the everyday card shape. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    strong: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit
) {
    GlassSurface(
        modifier = modifier,
        shape = shape,
        strong = strong,
        blurRadius = 12.dp,
        contentPadding = contentPadding,
        content = content
    )
}
