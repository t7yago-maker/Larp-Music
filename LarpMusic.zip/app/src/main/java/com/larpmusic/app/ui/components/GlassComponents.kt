package com.larpmusic.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.larpmusic.app.ui.theme.LarpGlassBorder
import com.larpmusic.app.ui.theme.LarpGlassFill
import com.larpmusic.app.ui.theme.LarpGlassFillStrong

/**
 * The single building block behind every panel, card, modal, nav bar and control in the app
 * (spec section 1): a translucent, neutral, bordered surface over a blurred backdrop.
 *
 * The blur is applied to its own separate background layer, never to the layer that holds
 * [content] — [Modifier.blur] blurs everything drawn inside the composable it's attached to,
 * so putting it on the same Box as the text/icons would blur them into illegibility (exactly
 * what happened before this was split into layers). True backdrop blur (sampling what's
 * actually behind the surface, e.g. album art scrolling underneath) requires Android 12+
 * (RenderEffect) and a dedicated library; this gives the translucent-glass look via color and
 * a soft edge without that dependency, which is an intentional, documented simplification.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    strong: Boolean = false,
    bordered: Boolean = true,
    blurRadius: Dp = 20.dp,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    content: @Composable () -> Unit
) {
    val fill = if (strong) LarpGlassFillStrong else LarpGlassFill
    Box(modifier = modifier.clip(shape)) {
        // Background layer: translucent fill + blur. Holds no text/icons, so blurring it
        // never affects legibility.
        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(blurRadius)
                .background(Brush.verticalGradient(listOf(fill, fill.copy(alpha = fill.alpha * 0.65f))))
        )
        // Border, drawn as its own unblurred layer on top of the background fill.
        if (bordered) {
            Box(modifier = Modifier.matchParentSize().border(1.dp, LarpGlassBorder, shape))
        }
        // Foreground layer: the actual content, always sharp.
        Box(modifier = Modifier.padding(contentPadding)) {
            content()
        }
    }
}

/** Glass panel with visible border and default content padding — the everyday card shape. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    strong: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit
) {
    GlassSurface(
        modifier = modifier,
        shape = shape,
        strong = strong,
        blurRadius = 12.dp,
        contentPadding = contentPadding,
        content = content
    )
}
