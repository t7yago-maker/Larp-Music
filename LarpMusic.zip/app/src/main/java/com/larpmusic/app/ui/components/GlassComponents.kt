package com.larpmusic.app.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Vidro líquido: base escura semitransparente (para o conteúdo que rola por baixo não vazar
 * pelo texto), preenchimento branco em degradê, brilho especular no topo e borda com luz
 * vindo do canto superior esquerdo. [strong] = barras/botões (mais opaco).
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    strong: Boolean = false,
    bordered: Boolean = true,
    blurRadius: Dp = 20.dp, // mantido por compatibilidade
    contentPadding: PaddingValues = PaddingValues(0.dp),
    content: @Composable () -> Unit
) {
    val base = if (strong) Color(0xD92A2A30) else Color(0x6B2A2A30)
    val top = if (strong) Color(0x40FFFFFF) else Color(0x2EFFFFFF)
    val bottom = if (strong) Color(0x12FFFFFF) else Color(0x0DFFFFFF)
    Box(
        modifier = modifier
            .clip(shape)
            .drawBehind {
                drawRect(base)
                drawRect(Brush.verticalGradient(listOf(top, bottom)))
                // brilho líquido no topo
                drawRect(
                    Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color.Transparent), 0f, size.height * 0.45f),
                    size = androidx.compose.ui.geometry.Size(size.width, size.height * 0.45f)
                )
            }
            .then(
                if (bordered) Modifier.border(
                    1.dp,
                    Brush.linearGradient(listOf(Color(0xAAFFFFFF), Color(0x14FFFFFF), Color(0x55FFFFFF))),
                    shape
                ) else Modifier
            )
    ) {
        Box(modifier = Modifier.padding(contentPadding)) { content() }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    strong: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable () -> Unit
) {
    GlassSurface(modifier = modifier, shape = shape, strong = strong, contentPadding = contentPadding, content = content)
}
