package com.larpmusic.app.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.larpmusic.app.domain.model.RepeatMode
import com.larpmusic.app.ui.theme.LarpBackground
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

/** Expanded now-playing screen (spec section 4): large artwork, smooth-feeling controls, glass menu. */
@Composable
fun PlayerScreen(navController: NavHostController, viewModel: PlayerViewModel = hiltViewModel()) {
    val playback by viewModel.playbackState.collectAsState()
    val position by viewModel.positionMs.collectAsState()
    val track = playback.currentTrack

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(LarpBackground)
            .padding(24.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = LarpTextPrimary)
            }
            Text("Tocando agora", style = MaterialTheme.typography.titleMedium, color = LarpTextSecondary)
            Box(modifier = Modifier.size(48.dp))
        }

        if (track == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Nada tocando no momento", color = LarpTextSecondary)
            }
            return@Column
        }

        Spacer(Modifier.height(32.dp))
        AsyncImage(
            model = track.artworkUrl,
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .clip(RoundedCornerShape(28.dp))
        )

        Spacer(Modifier.height(32.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.headlineMedium, color = LarpTextPrimary, maxLines = 2)
                Text(track.artistName, style = MaterialTheme.typography.bodyLarge, color = LarpTextSecondary)
            }
            val isFav by viewModel.isFavorite(track).collectAsState(initial = false)
            IconButton(onClick = { viewModel.toggleFavorite(track, !isFav) }) {
                Icon(
                    if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = null,
                    tint = LarpTextPrimary
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        val durationMs = playback.durationMs.coerceAtLeast(1L)
        Slider(
            value = position.toFloat().coerceIn(0f, durationMs.toFloat()),
            onValueChange = { viewModel.seekTo(it.toLong()) },
            valueRange = 0f..durationMs.toFloat(),
            colors = SliderDefaults.colors(thumbColor = LarpTextPrimary, activeTrackColor = LarpTextPrimary)
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatMs(position), color = LarpTextSecondary, style = MaterialTheme.typography.bodySmall)
            Text(formatMs(playback.durationMs), color = LarpTextSecondary, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { viewModel.setShuffle(!playback.shuffleEnabled) }) {
                Icon(Icons.Filled.Shuffle, contentDescription = null, tint = if (playback.shuffleEnabled) LarpTextPrimary else LarpTextSecondary)
            }
            IconButton(onClick = { viewModel.previous() }) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = null, tint = LarpTextPrimary, modifier = Modifier.size(36.dp))
            }
            IconButton(
                onClick = { viewModel.togglePlayPause() },
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(50))
                    .background(LarpTextPrimary)
            ) {
                Icon(
                    if (playback.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = LarpBackground,
                    modifier = Modifier.size(36.dp)
                )
            }
            IconButton(onClick = { viewModel.next() }) {
                Icon(Icons.Filled.SkipNext, contentDescription = null, tint = LarpTextPrimary, modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = { viewModel.cycleRepeat() }) {
                Icon(
                    if (playback.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = null,
                    tint = if (playback.repeatMode != RepeatMode.OFF) LarpTextPrimary else LarpTextSecondary
                )
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
