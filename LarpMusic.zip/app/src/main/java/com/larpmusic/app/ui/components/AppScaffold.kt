package com.larpmusic.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.larpmusic.app.ui.navigation.Screen
import com.larpmusic.app.ui.player.PlayerViewModel

/**
 * Shared chrome for every bottom-nav tab: dark backdrop, scrollable content, the floating
 * glass mini-player (only when something is loaded) and the glass bottom nav on top.
 */
@Composable
fun AppScaffold(
    navController: NavHostController,
    currentRoute: String?,
    playerViewModel: PlayerViewModel = hiltViewModel(),
    content: @Composable (bottomPaddingDp: Int) -> Unit
) {
    val playback by playerViewModel.playbackState.collectAsState()
    val position by playerViewModel.positionMs.collectAsState()

    Box(modifier = Modifier.fillMaxSize().liquidBackground()) {
        Box(modifier = Modifier.statusBarsPadding()) {
            content(if (playback.currentTrack != null) 170 else 100)
        }

        Box(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .height(if (playback.currentTrack != null) 190.dp else 130.dp)
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(androidx.compose.ui.graphics.Color.Transparent, androidx.compose.ui.graphics.Color(0xF0222226))))
        )
        Column(modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
            playback.currentTrack?.let { track ->
                val progress = if (playback.durationMs > 0) position.toFloat() / playback.durationMs else 0f
                androidx.compose.animation.AnimatedVisibility(
                    visible = true,
                    enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(450)) { it } + androidx.compose.animation.fadeIn()
                ) {
                MiniPlayer(
                    track = track,
                    isPlaying = playback.isPlaying,
                    progress = progress,
                    onTogglePlay = { playerViewModel.togglePlayPause() },
                    onNext = { playerViewModel.next() },
                    onOpenPlayer = { navController.navigate(Screen.Player.route) },
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                }
            }
            GlassBottomNav(currentRoute = currentRoute) { screen ->
                navController.navigate(screen.route) {
                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        }
    }
}
