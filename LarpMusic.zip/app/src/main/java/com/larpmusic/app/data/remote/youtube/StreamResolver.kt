package com.larpmusic.app.data.remote.youtube

import android.net.Uri
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.ResolvingDataSource
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

/** Turns the app's virtual `larp://` URIs into real http(s) audio URLs, at load time, off the UI thread. */
@Singleton
class StreamResolver @Inject constructor(private val youtube: YoutubeSource) : ResolvingDataSource.Resolver {

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val uri = dataSpec.uri
        if (uri.scheme != StreamUris.SCHEME) return dataSpec

        val resolved: String? = try {
            when (uri.host) {
                "yt" -> uri.getQueryParameter("id")?.let { youtube.resolveVideo(it) }
                "match" -> {
                    val full = youtube.resolveMatch(
                        uri.getQueryParameter("artist").orEmpty(),
                        uri.getQueryParameter("title").orEmpty(),
                        uri.getQueryParameter("dur")?.toIntOrNull() ?: 0
                    )
                    full ?: uri.getQueryParameter("preview") // 30s preview as a last resort
                }
                else -> null
            }
        } catch (e: Exception) {
            // Network/extractor failure: for Deezer tracks still play the preview.
            if (uri.host == "match") uri.getQueryParameter("preview") else throw IOException("Falha ao resolver áudio", e)
        }

        val finalUrl = resolved ?: throw IOException("Nenhum áudio encontrado para esta faixa")
        return dataSpec.buildUpon()
            .setUri(Uri.parse(finalUrl))
            .setHttpRequestHeaders(dataSpec.httpRequestHeaders + ("User-Agent" to userAgentFor(finalUrl)))
            .build()
    }

    /** googlevideo URLs only work with the User-Agent of the client that produced them. */
    private fun userAgentFor(url: String): String = when (Uri.parse(url).getQueryParameter("c")) {
        "ANDROID" -> "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip"
        "IOS" -> "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
        else -> NewPipeDownloader.USER_AGENT
    }
}
