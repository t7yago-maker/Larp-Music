package com.larpmusic.app.data.remote.youtube

import android.net.Uri

/**
 * Playable "virtual" URIs. The real audio URL is resolved lazily by [StreamResolver] right before
 * playback because YouTube stream URLs expire after a few hours.
 *   larp://yt?id=VIDEO_ID
 *   larp://match?artist=..&title=..&dur=..&preview=..
 */
object StreamUris {
    const val SCHEME = "larp"

    fun youtube(videoId: String): String = "$SCHEME://yt?id=$videoId"

    fun match(artist: String, title: String, durationSeconds: Int, previewUrl: String?): String =
        Uri.Builder().scheme(SCHEME).authority("match")
            .appendQueryParameter("artist", artist)
            .appendQueryParameter("title", title)
            .appendQueryParameter("dur", durationSeconds.toString())
            .apply { if (!previewUrl.isNullOrBlank()) appendQueryParameter("preview", previewUrl) }
            .build().toString()
}
