package com.larpmusic.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.AuthRepository
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.data.repository.SourceResult
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val greetingName: String = "",
    val recentlyPlayed: List<Track> = emptyList(),
    val popular: List<Track> = emptyList(),
    val newReleases: List<Track> = emptyList(),
    val sourceConfigured: Boolean = true,
    val error: String? = null,
    val loading: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val musicRepository: MusicRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    val recentlyPlayed: StateFlow<List<Track>> = musicRepository.recentlyPlayed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            val user = authRepository.currentUser()
            val popularResult = musicRepository.popularTracks()
            val releasesResult = musicRepository.newReleases()

            if (popularResult is SourceResult.NotConfigured) {
                _state.value = _state.value.copy(
                    loading = false,
                    sourceConfigured = false,
                    greetingName = user?.displayName ?: "",
                    error = "Catálogo Jamendo não configurado: defina JAMENDO_CLIENT_ID para ver recomendações, lançamentos e busca."
                )
                return@launch
            }

            val popular = (popularResult as? SourceResult.Success)?.data ?: emptyList()
            val releases = (releasesResult as? SourceResult.Success)?.data ?: emptyList()
            val error = (popularResult as? SourceResult.Error)?.message ?: (releasesResult as? SourceResult.Error)?.message

            _state.value = _state.value.copy(
                loading = false,
                sourceConfigured = true,
                greetingName = user?.displayName ?: "",
                popular = popular,
                newReleases = releases,
                error = error
            )
        }
    }
}
