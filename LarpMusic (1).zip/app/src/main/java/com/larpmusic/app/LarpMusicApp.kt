package com.larpmusic.app

import android.app.Application
import com.larpmusic.app.player.PlayerController
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class LarpMusicApp : Application() {
    @Inject lateinit var playerController: PlayerController

    override fun onCreate() {
        super.onCreate()
        // Bind to the playback service once, for the lifetime of the process.
        playerController.connect()
    }
}
