package com.larpmusic.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LarpColorScheme = darkColorScheme(
    background = LarpBackground,
    surface = LarpBackgroundElevated,
    primary = LarpAccent,
    onPrimary = LarpBackground,
    onBackground = LarpTextPrimary,
    onSurface = LarpTextPrimary,
    secondary = LarpTextSecondary,
    surfaceVariant = LarpGlassFill,
    outline = LarpGlassBorder
)

/**
 * LARP MUSIC always runs in a dark, neutral glass look regardless of system theme — the
 * spec calls for one deliberate premium identity, not a light/dark toggle that would fight
 * the glassmorphism concept.
 */
@Composable
fun LarpMusicTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        val window = (view.context as? android.app.Activity)?.window
        window?.let {
            WindowCompat.setDecorFitsSystemWindows(it, false)
        }
    }
    MaterialTheme(
        colorScheme = LarpColorScheme,
        typography = LarpTypography,
        content = content
    )
}
