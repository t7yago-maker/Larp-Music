package com.larpmusic.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.larpmusic.app.ui.auth.LoginScreen
import com.larpmusic.app.ui.auth.RegisterScreen
import com.larpmusic.app.ui.explore.ExploreScreen
import com.larpmusic.app.ui.home.HomeScreen
import com.larpmusic.app.ui.library.LibraryScreen
import com.larpmusic.app.ui.player.PlayerScreen
import com.larpmusic.app.ui.playlist.PlaylistDetailScreen
import com.larpmusic.app.ui.profile.ProfileScreen
import com.larpmusic.app.ui.search.SearchScreen
import com.larpmusic.app.ui.settings.SettingsScreen

@Composable
fun LarpNavGraph(navController: NavHostController, startDestination: String) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Login.route) { LoginScreen(navController) }
        composable(Screen.Register.route) { RegisterScreen(navController) }

        composable(Screen.Home.route) { HomeScreen(navController) }
        composable(Screen.Explore.route) { ExploreScreen(navController) }
        composable(Screen.Search.route) { SearchScreen(navController) }
        composable(Screen.Library.route) { LibraryScreen(navController) }
        composable(Screen.Profile.route) { ProfileScreen(navController) }

        composable(Screen.Player.route) { PlayerScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }

        composable(
            route = Screen.PlaylistDetail.route,
            arguments = listOf(navArgument("playlistId") { type = NavType.LongType })
        ) { backStackEntry ->
            val playlistId = backStackEntry.arguments?.getLong("playlistId") ?: 0L
            PlaylistDetailScreen(navController, playlistId)
        }
    }
}
