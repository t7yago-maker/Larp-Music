package com.larpmusic.app.player

import android.media.audiofx.Equalizer
import com.larpmusic.app.domain.model.EqualizerPreset
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Wraps Android's real audio effect framework (android.media.audiofx.Equalizer) attached to
 * ExoPlayer's audio session. These presets genuinely change the decoded audio signal — they
 * are not a cosmetic UI toggle, per the spec's requirement in section 7.
 *
 * Band gains are approximations tuned for a standard 5-band device equalizer; the actual
 * number of bands and their center frequencies vary by device and are read from the hardware
 * at [attach] time, then the closest matching curve is applied.
 */
@Singleton
class EqualizerManager @Inject constructor() {

    private var equalizer: Equalizer? = null

    // Gain curve per preset, expressed as 0..1 fractions of the device's max band level,
    // applied band-by-band from low to high frequency.
    private val presetCurves: Map<EqualizerPreset, List<Float>> = mapOf(
        EqualizerPreset.NORMAL to listOf(0.5f, 0.5f, 0.5f, 0.5f, 0.5f),
        EqualizerPreset.BASS_BOOST to listOf(0.95f, 0.8f, 0.5f, 0.4f, 0.4f),
        EqualizerPreset.ROCK to listOf(0.8f, 0.65f, 0.4f, 0.65f, 0.75f),
        EqualizerPreset.POP to listOf(0.55f, 0.7f, 0.75f, 0.6f, 0.45f),
        EqualizerPreset.JAZZ to listOf(0.65f, 0.6f, 0.45f, 0.6f, 0.65f),
        EqualizerPreset.CLASSICAL to listOf(0.6f, 0.55f, 0.5f, 0.55f, 0.65f),
        EqualizerPreset.ELECTRONIC to listOf(0.8f, 0.7f, 0.45f, 0.55f, 0.75f),
        EqualizerPreset.VOCAL to listOf(0.4f, 0.45f, 0.75f, 0.7f, 0.45f)
    )

    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 0

    fun minLevelMillibel(): Short = equalizer?.bandLevelRange?.get(0) ?: -1500
    fun maxLevelMillibel(): Short = equalizer?.bandLevelRange?.get(1) ?: 1500

    fun attach(audioSessionId: Int) {
        release()
        runCatching {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
        }
    }

    fun applyPreset(preset: EqualizerPreset) {
        val eq = equalizer ?: return
        val curve = presetCurves[preset] ?: return
        applyCurve(eq, curve)
    }

    fun applyCustomLevels(levelsMillibel: List<Int>) {
        val eq = equalizer ?: return
        levelsMillibel.forEachIndexed { index, level ->
            if (index < eq.numberOfBands) {
                runCatching { eq.setBandLevel(index.toShort(), level.toShort()) }
            }
        }
    }

    fun currentLevels(): List<Int> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfBands).map { eq.getBandLevel(it.toShort()).toInt() }
    }

    fun centerFrequenciesHz(): List<Int> {
        val eq = equalizer ?: return emptyList()
        return (0 until eq.numberOfBands).map { eq.getCenterFreq(it.toShort()) / 1000 }
    }

    private fun applyCurve(eq: Equalizer, curve: List<Float>) {
        val bands = eq.numberOfBands.toInt()
        if (bands == 0) return
        val min = eq.bandLevelRange[0]
        val max = eq.bandLevelRange[1]
        val range = (max - min)
        for (band in 0 until bands) {
            // Map our fixed 5-point curve onto however many bands this device actually has.
            val t = if (bands == 1) 0f else band.toFloat() / (bands - 1)
            val sourceIndex = (t * (curve.size - 1)).toInt().coerceIn(0, curve.size - 1)
            val fraction = curve[sourceIndex]
            val level = (min + range * fraction).toInt().toShort()
            runCatching { eq.setBandLevel(band.toShort(), level) }
        }
    }

    fun release() {
        equalizer?.release()
        equalizer = null
    }
}
