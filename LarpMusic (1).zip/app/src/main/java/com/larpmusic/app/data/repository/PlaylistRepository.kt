package com.larpmusic.app.data.repository

import com.larpmusic.app.data.local.db.CachedTrackEntity
import com.larpmusic.app.data.local.db.PlaylistDao
import com.larpmusic.app.data.local.db.PlaylistEntity
import com.larpmusic.app.data.local.db.PlaylistTrackEntity
import com.larpmusic.app.data.local.db.TrackCacheDao
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Playlist
import com.larpmusic.app.domain.model.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlaylistRepository @Inject constructor(
    private val playlistDao: PlaylistDao,
    private val trackCacheDao: TrackCacheDao
) {
    fun playlistsForUser(userId: Long): Flow<List<Playlist>> =
        playlistDao.playlistsForUser(userId).map { list -> list.map { it.toDomain() } }

    suspend fun create(userId: Long, name: String, isPublic: Boolean): Long =
        playlistDao.create(PlaylistEntity(ownerId = userId, name = name, isPublic = isPublic))

    suspend fun rename(playlist: Playlist, newName: String) {
        playlistDao.rename(playlist.id, newName)
    }

    suspend fun setCover(playlist: Playlist, coverUrl: String) {
        playlistDao.setCover(playlist.id, coverUrl)
    }

    suspend fun setVisibility(playlist: Playlist, isPublic: Boolean) {
        playlistDao.setVisibility(playlist.id, isPublic)
    }

    suspend fun delete(playlist: Playlist) {
        playlistDao.deleteById(playlist.id)
    }

    suspend fun duplicate(userId: Long, playlist: Playlist): Long {
        val newId = playlistDao.create(
            PlaylistEntity(ownerId = userId, name = "${playlist.name} (cópia)", isPublic = false)
        )
        val currentTracks = tracksFor(playlist.id).first()
        currentTracks.forEachIndexed { index, track ->
            playlistDao.addTrack(PlaylistTrackEntity(newId, track.source.name, track.id, index))
        }
        return newId
    }

    suspend fun addTrack(playlistId: Long, track: Track) {
        trackCacheDao.upsertAll(listOf(track.toCacheEntity()))
        val position = playlistDao.trackCount(playlistId)
        playlistDao.addTrack(
            PlaylistTrackEntity(playlistId, track.source.name, track.id, position)
        )
    }

    suspend fun removeTrack(playlistId: Long, track: Track) {
        playlistDao.removeTrack(playlistId, track.source.name, track.id)
    }

    suspend fun reorder(playlistId: Long, track: Track, newPosition: Int) {
        playlistDao.reorder(playlistId, track.source.name, track.id, newPosition)
    }

    fun tracksFor(playlistId: Long): Flow<List<Track>> =
        playlistDao.tracksForPlaylist(playlistId).map { list -> list.map { it.toDomain() } }

    private fun Track.toCacheEntity() = CachedTrackEntity(
        source.name, id, title, artistName, artistId, albumName, albumId, artworkUrl, streamUrl, durationSeconds
    )

    private fun CachedTrackEntity.toDomain() = Track(
        remoteId, MusicSource.valueOf(source), title, artistName, artistId,
        albumName, albumId, artworkUrl, streamUrl, durationSeconds
    )

    private fun PlaylistEntity.toDomain() = Playlist(id, name, coverUrl, isPublic)
}
