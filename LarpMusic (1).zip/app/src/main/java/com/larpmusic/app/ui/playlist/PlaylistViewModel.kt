package com.larpmusic.app.ui.playlist

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.local.db.PlaylistDao
import com.larpmusic.app.data.repository.PlaylistRepository
import com.larpmusic.app.domain.model.Playlist
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaylistViewModel @Inject constructor(
    private val playlistRepository: PlaylistRepository,
    private val playlistDao: PlaylistDao,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val playlistId: Long = savedStateHandle.get<Long>("playlistId") ?: 0L

    private val _playlist = MutableStateFlow<Playlist?>(null)
    val playlist: StateFlow<Playlist?> = _playlist.asStateFlow()

    val tracks: StateFlow<List<Track>> = playlistRepository.tracksFor(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            val entity = playlistDao.find(playlistId)
            entity?.let { _playlist.value = Playlist(it.id, it.name, it.coverUrl, it.isPublic) }
        }
    }

    fun removeTrack(track: Track) {
        viewModelScope.launch { playlistRepository.removeTrack(playlistId, track) }
    }

    fun rename(newName: String) {
        val p = _playlist.value ?: return
        viewModelScope.launch {
            playlistRepository.rename(p, newName)
            _playlist.value = p.copy(name = newName)
        }
    }

    fun setPublic(isPublic: Boolean) {
        val p = _playlist.value ?: return
        viewModelScope.launch {
            playlistRepository.setVisibility(p, isPublic)
            _playlist.value = p.copy(isPublic = isPublic)
        }
    }

    fun delete(onDone: () -> Unit) {
        val p = _playlist.value ?: return
        viewModelScope.launch {
            playlistRepository.delete(p)
            onDone()
        }
    }
}
