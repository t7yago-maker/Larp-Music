package com.larpmusic.app.data.remote.audius

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Audius public API — a real, open catalog that needs NO account, NO client id and NO manual
 * setup. `app_name` is only an identifier Audius asks apps to send.
 * Audio is streamed from [STREAM_URL_TEMPLATE] (the API answers with a redirect to a content node;
 * ExoPlayer follows it).
 */
interface AudiusApi {

    @GET("tracks/trending")
    suspend fun trending(
        @Query("app_name") app: String = APP_NAME,
        @Query("time") time: String = "week",
        @Query("genre") genre: String? = null,
        @Query("limit") limit: Int = 30
    ): AudiusTracksResponse

    @GET("tracks/trending/underground")
    suspend fun underground(
        @Query("app_name") app: String = APP_NAME,
        @Query("limit") limit: Int = 30
    ): AudiusTracksResponse

    @GET("tracks/search")
    suspend fun searchTracks(
        @Query("query") query: String,
        @Query("app_name") app: String = APP_NAME,
        @Query("limit") limit: Int = 30
    ): AudiusTracksResponse

    @GET("users/search")
    suspend fun searchUsers(
        @Query("query") query: String,
        @Query("app_name") app: String = APP_NAME,
        @Query("limit") limit: Int = 20
    ): AudiusUsersResponse

    @GET("playlists/search")
    suspend fun searchPlaylists(
        @Query("query") query: String,
        @Query("app_name") app: String = APP_NAME,
        @Query("limit") limit: Int = 30
    ): AudiusPlaylistsResponse

    companion object {
        const val APP_NAME = "LARPMUSIC"
        const val BASE_URL = "https://api.audius.co/v1/"
        fun streamUrl(trackId: String) = "${BASE_URL}tracks/$trackId/stream?app_name=$APP_NAME"
    }
}
