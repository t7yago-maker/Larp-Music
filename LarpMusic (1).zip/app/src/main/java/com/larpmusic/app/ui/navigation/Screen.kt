package com.larpmusic.app.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")

    object Home : Screen("home")
    object Explore : Screen("explore")
    object Search : Screen("search")
    object Library : Screen("library")
    object Profile : Screen("profile")

    object Player : Screen("player")
    object Settings : Screen("settings")

    object PlaylistDetail : Screen("playlist/{playlistId}") {
        fun build(playlistId: Long) = "playlist/$playlistId"
    }

    companion object {
        val bottomBarScreens = listOf(Home, Explore, Search, Library, Profile)
    }
}
