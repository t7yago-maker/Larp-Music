package com.larpmusic.app.data.remote.jamendo

import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track

fun JamendoTrackDto.toDomain(): Track? {
    // A track with no streamable audio URL is not playable; per the project's
    // quality rule, never present it as if it were.
    val stream = audio?.takeIf { it.isNotBlank() } ?: return null
    return Track(
        id = id,
        source = MusicSource.JAMENDO,
        title = name,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = image,
        streamUrl = stream,
        durationSeconds = duration
    )
}

fun JamendoArtistDto.toDomain() = Artist(
    id = id,
    source = MusicSource.JAMENDO,
    name = name,
    imageUrl = image
)

fun JamendoAlbumDto.toDomain() = Album(
    id = id,
    source = MusicSource.JAMENDO,
    title = name,
    artistName = artistName,
    artworkUrl = image
)
