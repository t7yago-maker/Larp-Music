package com.larpmusic.app.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import coil.compose.AsyncImage
import com.larpmusic.app.ui.auth.fieldColors
import com.larpmusic.app.ui.components.AppScaffold
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.components.TrackRow
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

@Composable
fun SearchScreen(
    navController: NavHostController,
    viewModel: SearchViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    AppScaffold(navController, currentRoute, playerViewModel) { bottomPadding ->
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = bottomPadding.dp)) {
            item {
                Text("Pesquisa", style = MaterialTheme.typography.displaySmall, color = LarpTextPrimary)
                OutlinedTextField(
                    value = state.query,
                    onValueChange = viewModel::onQueryChange,
                    placeholder = { Text("Músicas, artistas, álbuns...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = LarpTextSecondary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = fieldColors()
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                    SearchTab.entries.forEach { tab ->
                        GlassCard(
                            strong = tab == state.tab,
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.clickable { viewModel.setTab(tab) }
                        ) {
                            Text(
                                when (tab) { SearchTab.TRACKS -> "Músicas"; SearchTab.ARTISTS -> "Artistas"; SearchTab.ALBUMS -> "Álbuns" },
                                color = if (tab == state.tab) LarpTextPrimary else LarpTextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            if (!state.sourceConfigured) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("Catálogo indisponível no momento.", color = LarpTextSecondary)
                    }
                }
                return@LazyColumn
            }

            if (state.query.isBlank() && state.recentQueries.isNotEmpty()) {
                item { Text("Pesquisas recentes", style = MaterialTheme.typography.titleMedium, color = LarpTextPrimary, modifier = Modifier.padding(bottom = 8.dp)) }
                items(state.recentQueries) { q ->
                    Text(
                        q,
                        color = LarpTextSecondary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.onQueryChange(q) }
                            .padding(vertical = 10.dp)
                    )
                }
            }

            if (state.loading) {
                item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = LarpTextPrimary)
                    }
                }
            } else {
                when (state.tab) {
                    SearchTab.TRACKS -> items(state.tracks, key = { it.id }) { track ->
                        val isFav by playerViewModel.isFavorite(track).collectAsState(initial = false)
                        TrackRow(
                            track = track,
                            isFavorite = isFav,
                            onClick = { playerViewModel.playTrack(track, state.tracks) },
                            onToggleFavorite = { playerViewModel.toggleFavorite(track, !isFav) }
                        )
                    }
                    SearchTab.ARTISTS -> items(state.artists, key = { it.id }) { artist ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AsyncImage(model = artist.imageUrl, contentDescription = null, modifier = Modifier.size(48.dp).clip(CircleShape))
                            Text(artist.name, color = LarpTextPrimary, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                    SearchTab.ALBUMS -> items(state.albums, key = { it.id }) { album ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AsyncImage(model = album.artworkUrl, contentDescription = null, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)))
                            androidx.compose.foundation.layout.Column {
                                Text(album.title, color = LarpTextPrimary, style = MaterialTheme.typography.bodyLarge)
                                Text(album.artistName, color = LarpTextSecondary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
