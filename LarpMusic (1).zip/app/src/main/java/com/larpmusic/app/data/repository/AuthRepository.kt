package com.larpmusic.app.data.repository

import android.os.Build
import com.larpmusic.app.data.local.datastore.SettingsDataStore
import com.larpmusic.app.data.local.db.SessionDao
import com.larpmusic.app.data.local.db.SessionEntity
import com.larpmusic.app.data.local.db.UserDao
import com.larpmusic.app.data.local.db.UserEntity
import com.larpmusic.app.domain.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.mindrot.jbcrypt.BCrypt
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

sealed class AuthResult {
    data class Success(val user: User) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

/**
 * Real, working account system backed by Room + bcrypt password hashing (jBCrypt) and a
 * DataStore-persisted session token — this is what the spec's "autenticação real" item 5
 * means when no Firebase project has been wired in. It is fully local: there is no cloud
 * sync without a backend, which is explicitly documented as a missing-configuration item
 * rather than faked (see README "O que falta configurar").
 */
@Singleton
class AuthRepository @Inject constructor(
    private val userDao: UserDao,
    private val sessionDao: SessionDao,
    private val settings: SettingsDataStore
) {
    suspend fun register(username: String, password: String, displayName: String): AuthResult =
        withContext(Dispatchers.IO) {
            if (username.length < 3) return@withContext AuthResult.Error("Nome de usuário muito curto")
            if (password.length < 6) return@withContext AuthResult.Error("Senha deve ter ao menos 6 caracteres")
            if (userDao.findByUsername(username) != null) {
                return@withContext AuthResult.Error("Nome de usuário já existe")
            }
            val hash = BCrypt.hashpw(password, BCrypt.gensalt(12))
            val id = userDao.insert(
                UserEntity(username = username, passwordHash = hash, displayName = displayName.ifBlank { username })
            )
            startSession(id)
            val entity = userDao.findById(id)!!
            AuthResult.Success(entity.toDomain())
        }

    suspend fun login(username: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val entity = userDao.findByUsername(username)
            ?: return@withContext AuthResult.Error("Usuário ou senha incorretos")
        if (!BCrypt.checkpw(password, entity.passwordHash)) {
            return@withContext AuthResult.Error("Usuário ou senha incorretos")
        }
        startSession(entity.id)
        AuthResult.Success(entity.toDomain())
    }

    suspend fun logout() {
        val token = settings.sessionToken.first() ?: return
        sessionDao.delete(token)
        settings.setSessionToken(null)
    }

    suspend fun deleteAccount(userId: Long) = withContext(Dispatchers.IO) {
        sessionDao.deleteAllForUser(userId)
        userDao.delete(userId)
        settings.setSessionToken(null)
    }

    suspend fun currentUser(): User? = withContext(Dispatchers.IO) {
        val token = settings.sessionToken.first() ?: return@withContext null
        val session = sessionDao.find(token) ?: return@withContext null
        userDao.findById(session.userId)?.toDomain()
    }

    suspend fun updateProfile(userId: Long, displayName: String, bio: String?, avatarUrl: String?) =
        withContext(Dispatchers.IO) {
            val entity = userDao.findById(userId) ?: return@withContext
            userDao.update(entity.copy(displayName = displayName, bio = bio, avatarUrl = avatarUrl))
        }

    private suspend fun startSession(userId: Long) {
        val token = UUID.randomUUID().toString()
        sessionDao.insert(SessionEntity(token = token, userId = userId, device = Build.MODEL ?: "android"))
        settings.setSessionToken(token)
    }

    private fun UserEntity.toDomain() = User(id, username, displayName, bio, avatarUrl)
}
