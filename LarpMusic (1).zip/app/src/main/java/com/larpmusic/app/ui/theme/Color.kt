package com.larpmusic.app.ui.theme

import androidx.compose.ui.graphics.Color

// Neutral-only palette per the spec's "no colored glass" rule: pure blacks, whites and grays.
val LarpBackground = Color(0xFF07070A)
val LarpBackgroundElevated = Color(0xFF101014)
val LarpGlassFill = Color(0x1AFFFFFF)       // white @ 10% — translucent glass panel fill
val LarpGlassFillStrong = Color(0x29FFFFFF) // white @ 16% — active/selected glass state
val LarpGlassBorder = Color(0x33FFFFFF)     // white @ 20% — delicate glass edge
val LarpTextPrimary = Color(0xFFF5F5F7)
val LarpTextSecondary = Color(0xFFA0A0A8)
val LarpTextTertiary = Color(0xFF6B6B72)
val LarpAccent = Color(0xFFFFFFFF)          // accents are white/black only, never colored
