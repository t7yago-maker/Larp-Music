package com.larpmusic.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.larpmusic.app.ui.components.AlbumArtCard
import com.larpmusic.app.ui.components.AppScaffold
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

@Composable
fun HomeScreen(
    navController: NavHostController,
    viewModel: HomeViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsState()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    AppScaffold(navController, currentRoute, playerViewModel) { bottomPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = bottomPadding.dp)
        ) {
            item {
                Text(
                    if (state.greetingName.isNotBlank()) "Olá, ${state.greetingName}" else "Bem-vindo",
                    style = MaterialTheme.typography.displaySmall,
                    color = LarpTextPrimary
                )
                Text("O que você quer ouvir hoje?", style = MaterialTheme.typography.bodyLarge, color = LarpTextSecondary)
            }

            if (state.loading) {
                item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 40.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = LarpTextPrimary)
                    }
                }
                return@LazyColumn
            }

            if (!state.sourceConfigured) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(top = 24.dp)) {
                        Column {
                            Text("Catálogo musical não configurado", style = MaterialTheme.typography.titleMedium, color = LarpTextPrimary)
                            Text(
                                state.error ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = LarpTextSecondary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
                return@LazyColumn
            }

            if (recentlyPlayed.isNotEmpty()) {
                item { SectionTitle("Continuar ouvindo") }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                        items(recentlyPlayed, key = { it.source.name + it.id }) { track ->
                            AlbumArtCard(
                                title = track.title,
                                subtitle = track.artistName,
                                imageUrl = track.artworkUrl,
                                onClick = { playerViewModel.playTrack(track, recentlyPlayed) }
                            )
                        }
                    }
                }
            }

            if (state.popular.isNotEmpty()) {
                item { SectionTitle("Músicas em alta") }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                        items(state.popular, key = { "pop-" + it.id }) { track ->
                            AlbumArtCard(
                                title = track.title,
                                subtitle = track.artistName,
                                imageUrl = track.artworkUrl,
                                onClick = { playerViewModel.playTrack(track, state.popular) }
                            )
                        }
                    }
                }
            }

            if (state.newReleases.isNotEmpty()) {
                item { SectionTitle("Novos lançamentos") }
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                        items(state.newReleases, key = { "new-" + it.id }) { track ->
                            AlbumArtCard(
                                title = track.title,
                                subtitle = track.artistName,
                                imageUrl = track.artworkUrl,
                                onClick = { playerViewModel.playTrack(track, state.newReleases) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleLarge,
        color = LarpTextPrimary,
        modifier = Modifier.padding(top = 28.dp, bottom = 4.dp)
    )
}
