package com.larpmusic.app.data.local.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val displayName: String,
    val bio: String? = null,
    val avatarUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey val token: String,
    val userId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val device: String
)

/** Local cache of tracks pulled from any remote source, keyed by (source, remoteId). */
@Entity(tableName = "cached_tracks", primaryKeys = ["source", "remoteId"])
data class CachedTrackEntity(
    val source: String,
    val remoteId: String,
    val title: String,
    val artistName: String,
    val artistId: String,
    val albumName: String?,
    val albumId: String?,
    val artworkUrl: String?,
    val streamUrl: String,
    val durationSeconds: Int
)

@Entity(tableName = "favorites", primaryKeys = ["source", "remoteId"])
data class FavoriteEntity(
    val source: String,
    val remoteId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "followed_artists", primaryKeys = ["source", "remoteId"])
data class FollowedArtistEntity(
    val source: String,
    val remoteId: String,
    val name: String,
    val imageUrl: String?,
    val followedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val source: String,
    val remoteId: String,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ownerId: Long,
    val name: String,
    val coverUrl: String? = null,
    val isPublic: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "source", "remoteId"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("playlistId")]
)
data class PlaylistTrackEntity(
    val playlistId: Long,
    val source: String,
    val remoteId: String,
    val position: Int,
    val addedAt: Long = System.currentTimeMillis()
)
