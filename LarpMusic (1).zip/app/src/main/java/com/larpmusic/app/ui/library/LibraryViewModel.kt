package com.larpmusic.app.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.AuthRepository
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.data.repository.PlaylistRepository
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.Playlist
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class LibraryTab { FAVORITES, PLAYLISTS, ARTISTS, HISTORY }

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val musicRepository: MusicRepository,
    private val playlistRepository: PlaylistRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _tab = MutableStateFlow(LibraryTab.FAVORITES)
    val tab: StateFlow<LibraryTab> = _tab.asStateFlow()

    val favorites: StateFlow<List<Track>> = musicRepository.favorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val followedArtists: StateFlow<List<Artist>> = musicRepository.followedArtists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayed: StateFlow<List<Track>> = musicRepository.recentlyPlayed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    init {
        viewModelScope.launch {
            val user = authRepository.currentUser() ?: return@launch
            playlistRepository.playlistsForUser(user.id).collect { _playlists.value = it }
        }
    }

    fun selectTab(tab: LibraryTab) { _tab.value = tab }

    fun createPlaylist(name: String, isPublic: Boolean) {
        viewModelScope.launch {
            val user = authRepository.currentUser() ?: return@launch
            playlistRepository.create(user.id, name, isPublic)
        }
    }
}
