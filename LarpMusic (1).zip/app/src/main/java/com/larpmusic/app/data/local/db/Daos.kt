package com.larpmusic.app.data.local.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(user: UserEntity): Long

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun findByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun findById(id: Long): UserEntity?

    @Update
    suspend fun update(user: UserEntity)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface SessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: SessionEntity)

    @Query("SELECT * FROM sessions WHERE token = :token LIMIT 1")
    suspend fun find(token: String): SessionEntity?

    @Query("DELETE FROM sessions WHERE token = :token")
    suspend fun delete(token: String)

    @Query("DELETE FROM sessions WHERE userId = :userId")
    suspend fun deleteAllForUser(userId: Long)

    @Query("SELECT * FROM sessions WHERE userId = :userId")
    fun sessionsForUser(userId: Long): Flow<List<SessionEntity>>
}

@Dao
interface TrackCacheDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tracks: List<CachedTrackEntity>)

    @Query("SELECT * FROM cached_tracks WHERE source = :source AND remoteId = :remoteId LIMIT 1")
    suspend fun find(source: String, remoteId: String): CachedTrackEntity?

    @Query("SELECT * FROM cached_tracks WHERE source = :source AND remoteId IN (:ids)")
    suspend fun findAll(source: String, ids: List<String>): List<CachedTrackEntity>
}

@Dao
interface FavoriteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE source = :source AND remoteId = :remoteId")
    suspend fun remove(source: String, remoteId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE source = :source AND remoteId = :remoteId)")
    fun isFavorite(source: String, remoteId: String): Flow<Boolean>

    @Transaction
    @Query(
        """
        SELECT c.* FROM cached_tracks c
        INNER JOIN favorites f ON f.source = c.source AND f.remoteId = c.remoteId
        ORDER BY f.addedAt DESC
        """
    )
    fun favoriteTracks(): Flow<List<CachedTrackEntity>>
}

@Dao
interface FollowedArtistDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun follow(artist: FollowedArtistEntity)

    @Query("DELETE FROM followed_artists WHERE source = :source AND remoteId = :remoteId")
    suspend fun unfollow(source: String, remoteId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM followed_artists WHERE source = :source AND remoteId = :remoteId)")
    fun isFollowing(source: String, remoteId: String): Flow<Boolean>

    @Query("SELECT * FROM followed_artists ORDER BY followedAt DESC")
    fun followedArtists(): Flow<List<FollowedArtistEntity>>
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun record(entry: HistoryEntity)

    @Transaction
    @Query(
        """
        SELECT c.* FROM cached_tracks c
        INNER JOIN (
            SELECT source, remoteId, MAX(playedAt) AS lastPlayed
            FROM history GROUP BY source, remoteId
        ) h ON h.source = c.source AND h.remoteId = c.remoteId
        ORDER BY h.lastPlayed DESC
        LIMIT :limit
        """
    )
    fun recentlyPlayed(limit: Int = 25): Flow<List<CachedTrackEntity>>

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Dao
interface PlaylistDao {
    @Insert
    suspend fun create(playlist: PlaylistEntity): Long

    @Update
    suspend fun update(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("UPDATE playlists SET coverUrl = :coverUrl WHERE id = :id")
    suspend fun setCover(id: Long, coverUrl: String)

    @Query("UPDATE playlists SET isPublic = :isPublic WHERE id = :id")
    suspend fun setVisibility(id: Long, isPublic: Boolean)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Delete
    suspend fun delete(playlist: PlaylistEntity)

    @Query("SELECT * FROM playlists WHERE ownerId = :ownerId ORDER BY createdAt DESC")
    fun playlistsForUser(ownerId: Long): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun find(id: Long): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addTrack(entry: PlaylistTrackEntity)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND source = :source AND remoteId = :remoteId")
    suspend fun removeTrack(playlistId: Long, source: String, remoteId: String)

    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun trackCount(playlistId: Long): Int

    @Transaction
    @Query(
        """
        SELECT c.* FROM cached_tracks c
        INNER JOIN playlist_tracks pt ON pt.source = c.source AND pt.remoteId = c.remoteId
        WHERE pt.playlistId = :playlistId
        ORDER BY pt.position ASC
        """
    )
    fun tracksForPlaylist(playlistId: Long): Flow<List<CachedTrackEntity>>

    @Query("UPDATE playlist_tracks SET position = :position WHERE playlistId = :playlistId AND source = :source AND remoteId = :remoteId")
    suspend fun reorder(playlistId: Long, source: String, remoteId: String, position: Int)
}
