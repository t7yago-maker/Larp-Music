package com.larpmusic.app.ui.explore

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.larpmusic.app.ui.components.AppScaffold
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.components.TrackRow
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

@Composable
fun ExploreScreen(
    navController: NavHostController,
    viewModel: ExploreViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route

    LaunchedEffect(Unit) {
        if (state.selectedGenre == null) viewModel.selectGenre(exploreGenres.first())
    }

    AppScaffold(navController, currentRoute, playerViewModel) { bottomPadding ->
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = bottomPadding.dp)) {
            item {
                Text("Explorar", style = MaterialTheme.typography.displaySmall, color = LarpTextPrimary)
                Text("Descubra novos artistas e gêneros", style = MaterialTheme.typography.bodyLarge, color = LarpTextSecondary)
            }
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(exploreGenres) { genre ->
                        GenreChip(genre, selected = genre == state.selectedGenre) { viewModel.selectGenre(genre) }
                    }
                }
            }

            if (!state.sourceConfigured) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Catálogo indisponível no momento.",
                            color = LarpTextSecondary, style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                return@LazyColumn
            }

            if (state.loading) {
                item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = LarpTextPrimary)
                    }
                }
            } else {
                items(state.tracks, key = { it.id }) { track ->
                    val isFav by playerViewModel.isFavorite(track).collectAsState(initial = false)
                    TrackRow(
                        track = track,
                        isFavorite = isFav,
                        onClick = { playerViewModel.playTrack(track, state.tracks) },
                        onToggleFavorite = { playerViewModel.toggleFavorite(track, !isFav) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    GlassCard(
        shape = RoundedCornerShape(50),
        strong = selected,
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            label.replaceFirstChar { it.uppercase() },
            color = if (selected) LarpTextPrimary else LarpTextSecondary,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
