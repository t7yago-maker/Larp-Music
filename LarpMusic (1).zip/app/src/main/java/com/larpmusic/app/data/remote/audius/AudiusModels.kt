package com.larpmusic.app.data.remote.audius

import com.google.gson.annotations.SerializedName

// Raw DTOs for the Audius public REST API (https://docs.audius.org/api).
// Gson bypasses Kotlin default values, so EVERYTHING is nullable and checked in the mapper.

data class AudiusTracksResponse(val data: List<AudiusTrackDto>?)
data class AudiusUsersResponse(val data: List<AudiusUserDto>?)
data class AudiusPlaylistsResponse(val data: List<AudiusPlaylistDto>?)

data class AudiusArtwork(
    @SerializedName("150x150") val small: String?,
    @SerializedName("480x480") val medium: String?,
    @SerializedName("1000x1000") val large: String?
)

data class AudiusUserDto(
    val id: String?,
    val name: String?,
    val handle: String?,
    @SerializedName("profile_picture") val profilePicture: AudiusArtwork?
)

data class AudiusAccess(val stream: Boolean?, val download: Boolean?)

data class AudiusTrackDto(
    val id: String?,
    val title: String?,
    val duration: Int?,
    val genre: String?,
    val artwork: AudiusArtwork?,
    val user: AudiusUserDto?,
    @SerializedName("is_streamable") val isStreamable: Boolean?,
    @SerializedName("is_stream_gated") val isStreamGated: Boolean?,
    @SerializedName("is_delete") val isDelete: Boolean?,
    val access: AudiusAccess?
)

data class AudiusPlaylistDto(
    val id: String?,
    @SerializedName("playlist_name") val name: String?,
    @SerializedName("is_album") val isAlbum: Boolean?,
    val artwork: AudiusArtwork?,
    val user: AudiusUserDto?
)
