package com.larpmusic.app.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.domain.model.EqualizerPreset
import com.larpmusic.app.domain.model.Track
import com.larpmusic.app.player.EqualizerManager
import com.larpmusic.app.player.PlaybackUiState
import com.larpmusic.app.player.PlayerController
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Thin adapter between the singleton [PlayerController] and Compose. Several screens create their
 * own instance of this ViewModel, so it must hold NO state of its own and must NEVER release the
 * shared controller — all state lives in [PlayerController].
 */
@HiltViewModel
class PlayerViewModel @Inject constructor(
    private val playerController: PlayerController,
    private val musicRepository: MusicRepository,
    private val equalizerManager: EqualizerManager
) : ViewModel() {

    val playbackState: StateFlow<PlaybackUiState> = playerController.state
    val positionMs: StateFlow<Long> = playerController.positionMs

    init {
        playerController.connect() // idempotent
    }

    fun playTrack(track: Track, queue: List<Track> = listOf(track)) {
        val index = queue.indexOfFirst { it.id == track.id && it.source == track.source }.coerceAtLeast(0)
        playerController.playQueue(queue, index)
        viewModelScope.launch { musicRepository.recordPlay(track) }
    }

    fun togglePlayPause() = playerController.togglePlayPause()
    fun next() = playerController.skipToNext()
    fun previous() = playerController.skipToPrevious()
    fun seekTo(ms: Long) = playerController.seekTo(ms)
    fun setShuffle(enabled: Boolean) = playerController.setShuffle(enabled)
    fun cycleRepeat() = playerController.cycleRepeatMode()

    fun toggleFavorite(track: Track, favorite: Boolean) {
        viewModelScope.launch { musicRepository.toggleFavorite(track, favorite) }
    }

    fun isFavorite(track: Track) = musicRepository.isFavorite(track)

    fun applyEqualizerPreset(preset: EqualizerPreset) = equalizerManager.applyPreset(preset)
}
