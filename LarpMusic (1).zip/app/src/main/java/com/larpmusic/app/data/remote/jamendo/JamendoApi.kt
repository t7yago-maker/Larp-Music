package com.larpmusic.app.data.remote.jamendo

import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Retrofit interface for the Jamendo Music API (https://developer.jamendo.com/v3.0).
 * Jamendo hosts Creative-Commons-licensed tracks and allows free, legal streaming and
 * search through a registered client id — no scraping, no DRM bypass, no credentials
 * belonging to another service.
 *
 * Every call requires [clientId]; when it is blank (no JAMENDO_CLIENT_ID configured at
 * build time) [com.larpmusic.app.data.repository.MusicRepository] short-circuits before
 * ever calling this interface, and the UI shows an explicit "source not configured" state
 * instead of silently returning nothing.
 */
interface JamendoApi {

    @GET("tracks/")
    suspend fun searchTracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("search") query: String,
        @Query("limit") limit: Int = 30,
        @Query("include") include: String = "musicinfo",
        @Query("audioformat") audioFormat: String = "mp32"
    ): JamendoTrackResponse

    @GET("tracks/")
    suspend fun popularTracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("order") order: String = "popularity_total",
        @Query("limit") limit: Int = 30,
        @Query("audioformat") audioFormat: String = "mp32"
    ): JamendoTrackResponse

    @GET("tracks/")
    suspend fun newReleases(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("order") order: String = "releasedate_desc",
        @Query("limit") limit: Int = 30,
        @Query("audioformat") audioFormat: String = "mp32"
    ): JamendoTrackResponse

    @GET("artists/")
    suspend fun searchArtists(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("search") query: String,
        @Query("limit") limit: Int = 20
    ): JamendoArtistResponse

    @GET("albums/")
    suspend fun searchAlbums(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("search") query: String,
        @Query("limit") limit: Int = 20
    ): JamendoAlbumResponse

    @GET("playlists/")
    suspend fun featuredPlaylists(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 15
    ): JamendoPlaylistResponse
}
