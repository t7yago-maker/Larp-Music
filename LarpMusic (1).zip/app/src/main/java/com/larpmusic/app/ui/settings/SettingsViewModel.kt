package com.larpmusic.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.local.datastore.AudioSettings
import com.larpmusic.app.data.local.datastore.SettingsDataStore
import com.larpmusic.app.domain.model.EqualizerPreset
import com.larpmusic.app.player.EqualizerManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsDataStore: SettingsDataStore,
    private val equalizerManager: EqualizerManager
) : ViewModel() {

    val settings: StateFlow<AudioSettings> = settingsDataStore.audioSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AudioSettings())

    fun selectPreset(preset: EqualizerPreset) {
        viewModelScope.launch { settingsDataStore.setPreset(preset) }
        if (preset != EqualizerPreset.CUSTOM) equalizerManager.applyPreset(preset)
    }

    fun setCustomBandLevel(bandIndex: Int, levelMillibel: Int) {
        val current = equalizerManager.currentLevels().toMutableList()
        while (current.size <= bandIndex) current.add(0)
        current[bandIndex] = levelMillibel
        equalizerManager.applyCustomLevels(current)
        viewModelScope.launch {
            settingsDataStore.setCustomBands(current)
            settingsDataStore.setPreset(EqualizerPreset.CUSTOM)
        }
    }

    fun bandCount() = equalizerManager.bandCount
    fun minLevel() = equalizerManager.minLevelMillibel()
    fun maxLevel() = equalizerManager.maxLevelMillibel()
    fun centerFrequencies() = equalizerManager.centerFrequenciesHz()
    fun currentLevels() = equalizerManager.currentLevels()

    fun setVolumeNormalization(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setVolumeNormalization(enabled) }
    fun setCrossfade(seconds: Int) = viewModelScope.launch { settingsDataStore.setCrossfade(seconds) }
    fun setGapless(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setGapless(enabled) }
    fun setDataSaver(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setDataSaver(enabled) }
    fun setSleepTimer(minutes: Int) = viewModelScope.launch { settingsDataStore.setSleepTimer(minutes) }
}
