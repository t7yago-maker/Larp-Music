package com.larpmusic.app.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.AuthRepository
import com.larpmusic.app.data.repository.AuthResult
import com.larpmusic.app.domain.model.User
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val user: User? = null,
    val sessionResolved: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(private val authRepository: AuthRepository) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            _state.value = _state.value.copy(user = authRepository.currentUser(), sessionResolved = true)
        }
    }

    fun login(username: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            when (val result = authRepository.login(username, password)) {
                is AuthResult.Success -> {
                    _state.value = _state.value.copy(loading = false, user = result.user)
                    onSuccess()
                }
                is AuthResult.Error -> _state.value = _state.value.copy(loading = false, error = result.message)
            }
        }
    }

    fun register(username: String, password: String, displayName: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            when (val result = authRepository.register(username, password, displayName)) {
                is AuthResult.Success -> {
                    _state.value = _state.value.copy(loading = false, user = result.user)
                    onSuccess()
                }
                is AuthResult.Error -> _state.value = _state.value.copy(loading = false, error = result.message)
            }
        }
    }

    fun logout(onDone: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            _state.value = AuthUiState()
            onDone()
        }
    }

    fun deleteAccount(onDone: () -> Unit) {
        val userId = _state.value.user?.id ?: return
        viewModelScope.launch {
            authRepository.deleteAccount(userId)
            _state.value = AuthUiState()
            onDone()
        }
    }

    fun updateProfile(displayName: String, bio: String?, avatarUrl: String?) {
        val userId = _state.value.user?.id ?: return
        viewModelScope.launch {
            authRepository.updateProfile(userId, displayName, bio, avatarUrl)
            _state.value = _state.value.copy(user = authRepository.currentUser())
        }
    }
}
