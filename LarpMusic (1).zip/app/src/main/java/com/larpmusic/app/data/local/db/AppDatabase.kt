package com.larpmusic.app.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        SessionEntity::class,
        CachedTrackEntity::class,
        FavoriteEntity::class,
        FollowedArtistEntity::class,
        HistoryEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun sessionDao(): SessionDao
    abstract fun trackCacheDao(): TrackCacheDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun followedArtistDao(): FollowedArtistDao
    abstract fun historyDao(): HistoryDao
    abstract fun playlistDao(): PlaylistDao
}
