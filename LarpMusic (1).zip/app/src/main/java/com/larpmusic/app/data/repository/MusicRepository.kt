package com.larpmusic.app.data.repository

import com.larpmusic.app.BuildConfig
import com.larpmusic.app.data.local.db.CachedTrackEntity
import com.larpmusic.app.data.local.db.FavoriteEntity
import com.larpmusic.app.data.local.db.FollowedArtistEntity
import com.larpmusic.app.data.local.db.HistoryEntity
import com.larpmusic.app.data.local.db.TrackCacheDao
import com.larpmusic.app.data.local.db.FavoriteDao
import com.larpmusic.app.data.local.db.FollowedArtistDao
import com.larpmusic.app.data.local.db.HistoryDao
import com.larpmusic.app.data.remote.audius.AudiusApi
import com.larpmusic.app.data.remote.audius.toDomain
import com.larpmusic.app.data.remote.jamendo.JamendoApi
import com.larpmusic.app.data.remote.jamendo.toDomain
import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

sealed class SourceResult<out T> {
    data class Success<T>(val data: T) : SourceResult<T>()
    data class Error(val message: String) : SourceResult<Nothing>()
    /** Kept for UI compatibility; no longer returned because Audius needs no configuration. */
    object NotConfigured : SourceResult<Nothing>()
}

/**
 * Single entry point for all music catalog data.
 *  - Audius: always on, free, no key or manual setup (the default catalog).
 *  - Jamendo: optional extra catalog, merged in only if JAMENDO_CLIENT_ID was provided at build time.
 * If one source fails the other still answers; an Error is only returned when every source failed.
 */
@Singleton
class MusicRepository @Inject constructor(
    private val audiusApi: AudiusApi,
    private val jamendoApi: JamendoApi,
    private val trackCacheDao: TrackCacheDao,
    private val favoriteDao: FavoriteDao,
    private val followedArtistDao: FollowedArtistDao,
    private val historyDao: HistoryDao
) {
    private val jamendoId = BuildConfig.JAMENDO_CLIENT_ID
    private val jamendoOn get() = jamendoId.isNotBlank()

    /** Audius genre name for each Explore chip (Audius uses its own spelling). */
    private val audiusGenres = mapOf(
        "rock" to "Rock", "pop" to "Pop", "jazz" to "Jazz", "electronic" to "Electronic",
        "classical" to "Classical", "hiphop" to "Hip-Hop/Rap", "ambient" to "Ambient", "folk" to "Folk"
    )

    private suspend fun <T> catalog(
        failMessage: String,
        audius: suspend () -> List<T>,
        jamendo: (suspend () -> List<T>)? = null
    ): SourceResult<List<T>> = coroutineScope {
        val a = async { runCatching { audius() } }
        val j = async { if (jamendoOn && jamendo != null) runCatching { jamendo() } else null }
        val ar = a.await()
        val jr = j.await()
        val lists = listOfNotNull(ar.getOrNull(), jr?.getOrNull())
        if (lists.isEmpty()) {
            SourceResult.Error(ar.exceptionOrNull()?.let { "$failMessage: ${it.message ?: "sem conexão"}" } ?: failMessage)
        } else {
            SourceResult.Success(interleave(lists))
        }
    }

    private fun <T> interleave(lists: List<List<T>>): List<T> {
        val out = ArrayList<T>()
        var i = 0
        while (lists.any { i < it.size }) {
            lists.forEach { if (i < it.size) out.add(it[i]) }
            i++
        }
        return out
    }

    private suspend fun SourceResult<List<Track>>.cached(): SourceResult<List<Track>> {
        if (this is SourceResult.Success) cacheTracks(data)
        return this
    }

    suspend fun searchTracks(query: String): SourceResult<List<Track>> = catalog(
        "Falha na busca",
        audius = { audiusApi.searchTracks(query).data.orEmpty().mapNotNull { it.toDomain() } },
        jamendo = { jamendoApi.searchTracks(jamendoId, query = query).results.mapNotNull { it.toDomain() } }
    ).cached()

    suspend fun searchArtists(query: String): SourceResult<List<Artist>> = catalog(
        "Falha na busca de artistas",
        audius = { audiusApi.searchUsers(query).data.orEmpty().mapNotNull { it.toDomain() } },
        jamendo = { jamendoApi.searchArtists(jamendoId, query = query).results.map { it.toDomain() } }
    )

    suspend fun searchAlbums(query: String): SourceResult<List<Album>> = catalog(
        "Falha na busca de álbuns",
        audius = {
            audiusApi.searchPlaylists(query).data.orEmpty()
                .filter { it.isAlbum == true }.mapNotNull { it.toDomain() }
        },
        jamendo = { jamendoApi.searchAlbums(jamendoId, query = query).results.map { it.toDomain() } }
    )

    suspend fun popularTracks(): SourceResult<List<Track>> = catalog(
        "Falha ao carregar músicas em alta",
        audius = { audiusApi.trending().data.orEmpty().mapNotNull { it.toDomain() } },
        jamendo = { jamendoApi.popularTracks(jamendoId).results.mapNotNull { it.toDomain() } }
    ).cached()

    suspend fun newReleases(): SourceResult<List<Track>> = catalog(
        "Falha ao carregar lançamentos",
        audius = { audiusApi.underground().data.orEmpty().mapNotNull { it.toDomain() } },
        jamendo = { jamendoApi.newReleases(jamendoId).results.mapNotNull { it.toDomain() } }
    ).cached()

    /** Tracks for one Explore genre chip (e.g. "hiphop"). */
    suspend fun tracksByGenre(genre: String): SourceResult<List<Track>> = catalog(
        "Falha ao carregar o gênero",
        audius = {
            val name = audiusGenres[genre] ?: genre
            audiusApi.trending(time = "month", genre = name).data.orEmpty().mapNotNull { it.toDomain() }
        },
        jamendo = { jamendoApi.searchTracks(jamendoId, query = genre).results.mapNotNull { it.toDomain() } }
    ).cached()

    fun isConfigured() = true

    private suspend fun cacheTracks(tracks: List<Track>) {
        trackCacheDao.upsertAll(tracks.map { it.toCacheEntity() })
    }

    suspend fun recordPlay(track: Track) {
        cacheTracks(listOf(track))
        historyDao.record(HistoryEntity(source = track.source.name, remoteId = track.id))
    }

    fun recentlyPlayed(): Flow<List<Track>> =
        historyDao.recentlyPlayed().map { list -> list.map { it.toDomainWithFavorite() } }

    fun favorites(): Flow<List<Track>> =
        favoriteDao.favoriteTracks().map { list -> list.map { it.toDomain().copy(isFavorite = true) } }

    suspend fun toggleFavorite(track: Track, favorite: Boolean) {
        if (favorite) {
            cacheTracks(listOf(track))
            favoriteDao.add(FavoriteEntity(track.source.name, track.id))
        } else {
            favoriteDao.remove(track.source.name, track.id)
        }
    }

    fun isFavorite(track: Track): Flow<Boolean> = favoriteDao.isFavorite(track.source.name, track.id)

    fun followedArtists(): Flow<List<Artist>> = followedArtistDao.followedArtists().map { list ->
        list.map { Artist(it.remoteId, MusicSource.valueOf(it.source), it.name, it.imageUrl) }
    }

    suspend fun followArtist(artist: Artist, follow: Boolean) {
        if (follow) {
            followedArtistDao.follow(
                FollowedArtistEntity(artist.source.name, artist.id, artist.name, artist.imageUrl)
            )
        } else {
            followedArtistDao.unfollow(artist.source.name, artist.id)
        }
    }

    fun isFollowingArtist(artist: Artist): Flow<Boolean> =
        followedArtistDao.isFollowing(artist.source.name, artist.id)

    private fun Track.toCacheEntity() = CachedTrackEntity(
        source = source.name,
        remoteId = id,
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomain() = Track(
        id = remoteId,
        source = MusicSource.valueOf(source),
        title = title,
        artistName = artistName,
        artistId = artistId,
        albumName = albumName,
        albumId = albumId,
        artworkUrl = artworkUrl,
        streamUrl = streamUrl,
        durationSeconds = durationSeconds
    )

    private fun CachedTrackEntity.toDomainWithFavorite() = toDomain()
}
