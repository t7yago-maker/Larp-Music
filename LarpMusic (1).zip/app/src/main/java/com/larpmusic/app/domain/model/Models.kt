package com.larpmusic.app.domain.model

/**
 * Core domain models used across the UI, player and repositories.
 * Kept source-agnostic on purpose: a track doesn't know whether it came from
 * Jamendo, Audius or a future source, only which [source] produced it.
 */

enum class MusicSource { JAMENDO, AUDIUS }

data class Track(
    val id: String,
    val source: MusicSource,
    val title: String,
    val artistName: String,
    val artistId: String,
    val albumName: String?,
    val albumId: String?,
    val artworkUrl: String?,
    val streamUrl: String,
    val durationSeconds: Int,
    val isFavorite: Boolean = false
)

data class Artist(
    val id: String,
    val source: MusicSource,
    val name: String,
    val imageUrl: String?
)

data class Album(
    val id: String,
    val source: MusicSource,
    val title: String,
    val artistName: String,
    val artworkUrl: String?
)

data class Playlist(
    val id: Long,
    val name: String,
    val coverUrl: String?,
    val isPublic: Boolean,
    val trackCount: Int = 0
)

data class User(
    val id: Long,
    val username: String,
    val displayName: String,
    val bio: String?,
    val avatarUrl: String?
)

enum class RepeatMode { OFF, ONE, ALL }

enum class EqualizerPreset(val label: String) {
    NORMAL("Normal"),
    BASS_BOOST("Bass Boost"),
    ROCK("Rock"),
    POP("Pop"),
    JAZZ("Jazz"),
    CLASSICAL("Clássico"),
    ELECTRONIC("Eletrônica"),
    VOCAL("Vocal"),
    CUSTOM("Personalizado")
}
