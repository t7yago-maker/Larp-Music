package com.larpmusic.app.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.larpmusic.app.domain.model.EqualizerPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "larpmusic_settings")

data class AudioSettings(
    val equalizerPreset: EqualizerPreset = EqualizerPreset.NORMAL,
    val customBandLevelsMillibel: List<Int> = emptyList(),
    val volumeNormalization: Boolean = true,
    val crossfadeSeconds: Int = 0,
    val gaplessPlayback: Boolean = true,
    val dataSaver: Boolean = false,
    val sleepTimerMinutes: Int = 0
)

@Singleton
class SettingsDataStore @Inject constructor(private val context: Context) {

    private object Keys {
        val PRESET = stringPreferencesKey("eq_preset")
        val CUSTOM_BANDS = stringPreferencesKey("eq_custom_bands")
        val VOLUME_NORM = booleanPreferencesKey("volume_normalization")
        val CROSSFADE = intPreferencesKey("crossfade_seconds")
        val GAPLESS = booleanPreferencesKey("gapless_playback")
        val DATA_SAVER = booleanPreferencesKey("data_saver")
        val SLEEP_TIMER = intPreferencesKey("sleep_timer_minutes")
        val LAST_SESSION_TOKEN = stringPreferencesKey("last_session_token")
    }

    val audioSettings: Flow<AudioSettings> = context.dataStore.data.map { prefs ->
        AudioSettings(
            equalizerPreset = prefs[Keys.PRESET]?.let { runCatching { EqualizerPreset.valueOf(it) }.getOrNull() }
                ?: EqualizerPreset.NORMAL,
            customBandLevelsMillibel = prefs[Keys.CUSTOM_BANDS]
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?: emptyList(),
            volumeNormalization = prefs[Keys.VOLUME_NORM] ?: true,
            crossfadeSeconds = prefs[Keys.CROSSFADE] ?: 0,
            gaplessPlayback = prefs[Keys.GAPLESS] ?: true,
            dataSaver = prefs[Keys.DATA_SAVER] ?: false,
            sleepTimerMinutes = prefs[Keys.SLEEP_TIMER] ?: 0
        )
    }

    val sessionToken: Flow<String?> = context.dataStore.data.map { it[Keys.LAST_SESSION_TOKEN] }

    suspend fun setSessionToken(token: String?) {
        context.dataStore.edit {
            if (token == null) it.remove(Keys.LAST_SESSION_TOKEN) else it[Keys.LAST_SESSION_TOKEN] = token
        }
    }

    suspend fun setPreset(preset: EqualizerPreset) {
        context.dataStore.edit { it[Keys.PRESET] = preset.name }
    }

    suspend fun setCustomBands(levelsMillibel: List<Int>) {
        context.dataStore.edit { it[Keys.CUSTOM_BANDS] = levelsMillibel.joinToString(",") }
    }

    suspend fun setVolumeNormalization(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOLUME_NORM] = enabled }
    }

    suspend fun setCrossfade(seconds: Int) {
        context.dataStore.edit { it[Keys.CROSSFADE] = seconds }
    }

    suspend fun setGapless(enabled: Boolean) {
        context.dataStore.edit { it[Keys.GAPLESS] = enabled }
    }

    suspend fun setDataSaver(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DATA_SAVER] = enabled }
    }

    suspend fun setSleepTimer(minutes: Int) {
        context.dataStore.edit { it[Keys.SLEEP_TIMER] = minutes }
    }
}
