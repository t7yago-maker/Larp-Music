package com.larpmusic.app.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import coil.compose.AsyncImage
import com.larpmusic.app.ui.auth.fieldColors
import com.larpmusic.app.ui.components.AppScaffold
import com.larpmusic.app.ui.components.GlassCard
import com.larpmusic.app.ui.components.TrackRow
import com.larpmusic.app.ui.navigation.Screen
import com.larpmusic.app.ui.player.PlayerViewModel
import com.larpmusic.app.ui.theme.LarpTextPrimary
import com.larpmusic.app.ui.theme.LarpTextSecondary

@Composable
fun LibraryScreen(
    navController: NavHostController,
    viewModel: LibraryViewModel = hiltViewModel(),
    playerViewModel: PlayerViewModel = hiltViewModel()
) {
    val tab by viewModel.tab.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val artists by viewModel.followedArtists.collectAsState()
    val history by viewModel.recentlyPlayed.collectAsState()
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    var showCreateDialog by remember { mutableStateOf(false) }

    AppScaffold(navController, currentRoute, playerViewModel) { bottomPadding ->
        LazyColumn(contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = bottomPadding.dp)) {
            item { Text("Biblioteca", style = MaterialTheme.typography.displaySmall, color = LarpTextPrimary) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 16.dp)) {
                    LibraryTab.entries.forEach { t ->
                        GlassCard(
                            strong = t == tab,
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.clickable { viewModel.selectTab(t) }
                        ) {
                            Text(t.label(), color = if (t == tab) LarpTextPrimary else LarpTextSecondary, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            when (tab) {
                LibraryTab.FAVORITES -> {
                    if (favorites.isEmpty()) item { EmptyHint("Nenhuma música favoritada ainda.") }
                    items(favorites, key = { it.id }) { track ->
                        TrackRow(track, isFavorite = true, onClick = { playerViewModel.playTrack(track, favorites) }, onToggleFavorite = { playerViewModel.toggleFavorite(track, false) })
                    }
                }
                LibraryTab.PLAYLISTS -> {
                    item {
                        TextButton(onClick = { showCreateDialog = true }) { Text("+ Nova playlist", color = LarpTextPrimary) }
                    }
                    if (playlists.isEmpty()) item { EmptyHint("Você ainda não criou nenhuma playlist.") }
                    items(playlists, key = { it.id }) { playlist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { navController.navigate(Screen.PlaylistDetail.build(playlist.id)) }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(playlist.name, color = LarpTextPrimary, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                LibraryTab.ARTISTS -> {
                    if (artists.isEmpty()) item { EmptyHint("Você ainda não segue nenhum artista.") }
                    items(artists, key = { it.id }) { artist ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            AsyncImage(model = artist.imageUrl, contentDescription = null, modifier = Modifier.size(44.dp).clip(CircleShape))
                            Text(artist.name, color = LarpTextPrimary, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                LibraryTab.HISTORY -> {
                    if (history.isEmpty()) item { EmptyHint("Nenhum histórico de reprodução ainda.") }
                    items(history, key = { it.id }) { track ->
                        val isFav by playerViewModel.isFavorite(track).collectAsState(initial = false)
                        TrackRow(track, isFavorite = isFav, onClick = { playerViewModel.playTrack(track, history) }, onToggleFavorite = { playerViewModel.toggleFavorite(track, !isFav) })
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, isPublic -> viewModel.createPlaylist(name, isPublic); showCreateDialog = false }
        )
    }
}

private fun LibraryTab.label() = when (this) {
    LibraryTab.FAVORITES -> "Favoritas"
    LibraryTab.PLAYLISTS -> "Playlists"
    LibraryTab.ARTISTS -> "Artistas"
    LibraryTab.HISTORY -> "Histórico"
}

@Composable
private fun EmptyHint(text: String) {
    Text(text, color = LarpTextSecondary, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 24.dp))
}

@Composable
private fun CreatePlaylistDialog(onDismiss: () -> Unit, onCreate: (String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name, false) }) { Text("Criar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        title = { Text("Nova playlist") },
        text = {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome da playlist") }, colors = fieldColors())
        }
    )
}
