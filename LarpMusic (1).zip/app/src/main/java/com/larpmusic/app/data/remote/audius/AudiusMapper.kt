package com.larpmusic.app.data.remote.audius

import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.MusicSource
import com.larpmusic.app.domain.model.Track

private fun AudiusArtwork?.best(): String? = this?.medium ?: this?.large ?: this?.small

fun AudiusTrackDto.toDomain(): Track? {
    val trackId = id?.takeIf { it.isNotBlank() } ?: return null
    // Never show something that can't be played (gated / deleted / non-streamable).
    if (isDelete == true || isStreamable == false || isStreamGated == true || access?.stream == false) return null
    val name = title?.takeIf { it.isNotBlank() } ?: return null
    return Track(
        id = trackId,
        source = MusicSource.AUDIUS,
        title = name,
        artistName = user?.name ?: user?.handle ?: "Artista desconhecido",
        artistId = user?.id ?: "",
        albumName = genre,
        albumId = null,
        artworkUrl = artwork.best(),
        streamUrl = AudiusApi.streamUrl(trackId),
        durationSeconds = duration ?: 0
    )
}

fun AudiusUserDto.toDomain(): Artist? {
    val userId = id?.takeIf { it.isNotBlank() } ?: return null
    return Artist(userId, MusicSource.AUDIUS, name ?: handle ?: return null, profilePicture.best())
}

fun AudiusPlaylistDto.toDomain(): Album? {
    val pid = id?.takeIf { it.isNotBlank() } ?: return null
    return Album(pid, MusicSource.AUDIUS, name ?: return null, user?.name ?: "", artwork.best())
}
