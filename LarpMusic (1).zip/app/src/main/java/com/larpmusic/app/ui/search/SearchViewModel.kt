package com.larpmusic.app.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larpmusic.app.data.repository.MusicRepository
import com.larpmusic.app.data.repository.SourceResult
import com.larpmusic.app.domain.model.Album
import com.larpmusic.app.domain.model.Artist
import com.larpmusic.app.domain.model.Track
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class SearchTab { TRACKS, ARTISTS, ALBUMS }

data class SearchUiState(
    val query: String = "",
    val tab: SearchTab = SearchTab.TRACKS,
    val tracks: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
    val recentQueries: List<String> = emptyList(), // session-only history (see README)
    val loading: Boolean = false,
    val sourceConfigured: Boolean = true,
    val error: String? = null
)

@OptIn(FlowPreview::class)
@HiltViewModel
class SearchViewModel @Inject constructor(private val musicRepository: MusicRepository) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    private val queryFlow = MutableStateFlow("")

    init {
        queryFlow
            .debounce(350)
            .distinctUntilChanged()
            .filter { it.isNotBlank() }
            .onEach { runSearch(it) }
            .launchIn(viewModelScope)
    }

    fun onQueryChange(value: String) {
        _state.value = _state.value.copy(query = value)
        queryFlow.value = value
        if (value.isBlank()) _state.value = _state.value.copy(tracks = emptyList(), artists = emptyList(), albums = emptyList())
    }

    fun setTab(tab: SearchTab) {
        _state.value = _state.value.copy(tab = tab)
        if (_state.value.query.isNotBlank()) runSearch(_state.value.query)
    }

    private fun runSearch(query: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            if (!_state.value.recentQueries.contains(query)) {
                _state.value = _state.value.copy(recentQueries = (listOf(query) + _state.value.recentQueries).take(10))
            }
            when (_state.value.tab) {
                SearchTab.TRACKS -> when (val r = musicRepository.searchTracks(query)) {
                    is SourceResult.Success -> _state.value = _state.value.copy(loading = false, tracks = r.data, sourceConfigured = true)
                    is SourceResult.Error -> _state.value = _state.value.copy(loading = false, error = r.message)
                    SourceResult.NotConfigured -> _state.value = _state.value.copy(loading = false, sourceConfigured = false)
                }
                SearchTab.ARTISTS -> when (val r = musicRepository.searchArtists(query)) {
                    is SourceResult.Success -> _state.value = _state.value.copy(loading = false, artists = r.data, sourceConfigured = true)
                    is SourceResult.Error -> _state.value = _state.value.copy(loading = false, error = r.message)
                    SourceResult.NotConfigured -> _state.value = _state.value.copy(loading = false, sourceConfigured = false)
                }
                SearchTab.ALBUMS -> when (val r = musicRepository.searchAlbums(query)) {
                    is SourceResult.Success -> _state.value = _state.value.copy(loading = false, albums = r.data, sourceConfigured = true)
                    is SourceResult.Error -> _state.value = _state.value.copy(loading = false, error = r.message)
                    SourceResult.NotConfigured -> _state.value = _state.value.copy(loading = false, sourceConfigured = false)
                }
            }
        }
    }
}
