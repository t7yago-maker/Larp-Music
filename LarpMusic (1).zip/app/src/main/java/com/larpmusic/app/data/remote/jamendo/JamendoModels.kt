package com.larpmusic.app.data.remote.jamendo

import com.google.gson.annotations.SerializedName

// Raw DTOs mirroring the Jamendo v3.0 JSON response shape.
// Mapping into app-level domain.model.Track/Artist/Album happens in JamendoMapper.kt
// so the rest of the app never depends on this wire format directly.

data class JamendoTrackResponse(
    val headers: JamendoHeaders,
    val results: List<JamendoTrackDto>
)

data class JamendoArtistResponse(
    val headers: JamendoHeaders,
    val results: List<JamendoArtistDto>
)

data class JamendoAlbumResponse(
    val headers: JamendoHeaders,
    val results: List<JamendoAlbumDto>
)

data class JamendoPlaylistResponse(
    val headers: JamendoHeaders,
    val results: List<JamendoPlaylistDto>
)

data class JamendoHeaders(
    val status: String,
    @SerializedName("code") val code: Int,
    @SerializedName("error_message") val errorMessage: String?,
    val results_count: Int
)

data class JamendoTrackDto(
    val id: String,
    val name: String,
    val duration: Int,
    @SerializedName("artist_id") val artistId: String,
    @SerializedName("artist_name") val artistName: String,
    @SerializedName("album_id") val albumId: String?,
    @SerializedName("album_name") val albumName: String?,
    val image: String?,
    val audio: String?,
    val audiodownload: String?
)

data class JamendoArtistDto(
    val id: String,
    val name: String,
    val image: String?
)

data class JamendoAlbumDto(
    val id: String,
    val name: String,
    @SerializedName("artist_name") val artistName: String,
    val image: String?
)

data class JamendoPlaylistDto(
    val id: String,
    val name: String,
    @SerializedName("user_name") val userName: String?,
    val image: String? = null
)
