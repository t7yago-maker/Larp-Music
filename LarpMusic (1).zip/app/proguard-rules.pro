# Keep Retrofit/Gson model classes
-keep class com.larpmusic.app.data.remote.jamendo.** { *; }
-keep class com.larpmusic.app.data.remote.audius.** { *; }
-keep class com.larpmusic.app.data.local.db.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn retrofit2.**
